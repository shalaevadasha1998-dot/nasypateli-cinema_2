# UX audit — why v0.6.x felt raw

## 1. onboarding was a questionnaire, not an entrance
The underlying questions were useful, but every step had the same visual weight: title, fields, button. Nothing accumulated emotionally. The user was filling a database before being allowed into the product.

v0.7 keeps the data model but changes pacing: full-screen chapters, calmer spacing, progressive visual atmosphere, a visible journey counter, and a stronger transition from profile completion directly into birth.

## 2. birth had the right idea but no animation grammar
The old scene swapped CSS states quickly. The result read as UI moving around, not a small creature physically emerging.

The new sequence uses anticipation -> rattle -> ears -> jump -> landing -> idle -> named reaction. Shadow, popcorn particles, cup displacement and haptics all follow the same timing curve. The rabbit is intentionally small so growth has meaning later.

## 3. naming had no reward
After naming, the experience jumped to another screen. That made the most important emotional action feel like form submission.

v0.7 adds a named/success phase. The rabbit reacts before the interface moves on.

## 4. home looked like an admin dashboard
Rabbit card, event card, action card, Jipitina card: everything had equal visual priority.

v0.7 gives home a hierarchy: living rabbit -> upcoming evening -> current action -> Jipitina. Commerce stays visible without becoming the visual identity.

## 5. errors leaked infrastructure language
`Telegram initData is missing` is a developer message. `Admin access required` on participant flow is worse because it suggests the user is doing something wrong.

v0.7 adds a branded browser recovery state, isolates participant birth in the API, and keeps technical errors in contextual inline states.

## 6. the visual system did not match the brand system strongly enough
The product already had the correct black / dirty-light / green / red-orange palette and the rabbit, but the component language still looked like a generic dark SaaS app.

v0.7 adds printed texture, hairline glass, projector-light depth, one strange focal object per chapter, stronger typography scale and less visible UI chrome.

## release principle
This is not an Apple clone. It borrows the useful product qualities: ruthless hierarchy, generous negative space, continuity, motion with physical cause, and one clear action per scene. The surface remains recognizably NASYPATELI.

# v0.7.0 — cinematic experience pass

## participant journey
- redesigned onboarding as one continuous cinematic product rather than a stack of forms
- kept all existing profile data and backend contracts; the change is presentation, pacing and motion
- onboarding completion now goes directly into the birth scene instead of bouncing through home
- direct-browser `Telegram initData is missing` now has a branded recovery screen with a direct bot CTA

## creature birth
- rebuilt the birth sequence around a real popcorn cup, anticipation, ear peek, crumbs, jump, landing, idle and post-name movement
- uses the canonical rabbit assets already in the product; the rabbit stays deliberately small at birth
- naming now has a dedicated success phase before entering home
- frontend calls the isolated `participant-birth-v2` action so birth cannot fall into admin routing
- server health version bumped to `0.7.0`

## home
- replaced the generic creature card-first dashboard with a living rabbit hero
- event ticket is now the second visual chapter, with stronger hierarchy and calmer commerce UI
- Jipitina is presented as a portal rather than another generic card

## design system
- glass/hairline surfaces, larger spatial rhythm, full-screen chapter transitions, subtle grain and projector-light depth
- refined buttons, form fields, chips, bottom navigation, focus states and haptics
- added reduced-motion fallback

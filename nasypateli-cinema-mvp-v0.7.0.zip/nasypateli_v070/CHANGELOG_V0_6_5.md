# v0.6.5

- Reworked creature birth scene: recognisable popcorn cup, no copy overlap, smaller baby rabbit, calmer reveal animation.
- Moved `birth-creature` before all admin-only routing so participant onboarding can never fall through to the admin guard.
- Added GET health response on the Edge Function and bumped backend health version to 0.6.5 for easy deployment verification.

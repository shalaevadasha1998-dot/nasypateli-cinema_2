# Legal / cost notes (needs final specialist/provider confirmation)

## Public screening
A normal purchased/downloaded file is not automatically a public-screening license. For a room with people outside the ordinary family circle, Russian Civil Code art. 1270 treats screen exhibition/public performance as a use controlled by the rightholder. Resolve screening rights before event.

## Online
Streaming one copy of a film to a group creates additional copyright/communication risks. Do not implement group streaming until rights are confirmed. Safer product architecture: synchronized session where each participant opens their own lawful copy; revisit if a distributor licenses group streaming.

## OpenAI
OpenAI API is not free. Keep AI server-side, use a low-cost model for bounded tasks, hard-cap spend, cache successful generations, and avoid free-form chatting in MVP.

## Hosting
Cloudflare + Supabase free tiers are sufficient for MVP scale. Avoid Vercel Hobby for this commercial use case.

## Payments
Offline event ticket can be implemented through Telegram Bot Payments + YooKassa. Online/digital services inside Telegram may fall under Telegram Stars rules; treat online paid product as a separate payment design decision.

## Movie metadata
Do not rely on TMDB developer API as the free default for this revenue-generating project: TMDB states the free developer API is for non-commercial use. MVP validation should use open data (e.g. Wikidata) plus a manual availability check.

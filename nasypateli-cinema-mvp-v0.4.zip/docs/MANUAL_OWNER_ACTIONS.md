# What still requires the owner / account holder

These cannot be safely automated without credentials/approval.

1. @BotFather: create Telegram bot and obtain BOT_TOKEN.
2. @BotFather: attach Mini App domain after deploy.
3. Supabase project is already created and wired to ref `vwteokawtqnoiyzmsldj`. Apply `supabase/SETUP_THIS_PROJECT.sql`; do not send database secret keys in chat.
4. OpenAI: provide API key and set a hard monthly budget cap.
5. No paid movie database is required for MVP: default validation uses open data. A licensed commercial movie-data provider can be added later.
6. YooKassa: register/verify self-employed merchant, connect Telegram payment provider, obtain provider token / API credentials.
7. Rights holder/distributor: obtain lawful public-screening permission for selected film or use a film/source with appropriate public exhibition rights.
8. Cloudflare/GitHub: connect repository to deployment.

Never put any secret in the Mini App frontend or GitHub repository.

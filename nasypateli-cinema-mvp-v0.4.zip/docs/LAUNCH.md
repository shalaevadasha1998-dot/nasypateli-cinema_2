# Запуск MVP

Актуальный быстрый сценарий находится в `DEPLOY_NOW.md`.

Главное изменение v0.4: для первого мероприятия отдельный frontend-хостинг больше не нужен. Supabase Edge Function `app` одновременно обслуживает Mini App, API, админку, экран, Telegram webhook и invoice endpoint.

## URLs после deploy

Mini App:
`https://vwteokawtqnoiyzmsldj.supabase.co/functions/v1/app`

Webhook:
`https://vwteokawtqnoiyzmsldj.supabase.co/functions/v1/app?mode=telegram`

Invoice endpoint:
`https://vwteokawtqnoiyzmsldj.supabase.co/functions/v1/app?mode=invoice`

Admin/screen URLs создаются из приватных `ADMIN_ACCESS_TOKEN` / `SCREEN_ACCESS_TOKEN` и хранятся вне репозитория.

## Почему built-in JWT verification выключен

Функцию вызывают Telegram webhook и браузер Mini App без Supabase user JWT. Поэтому platform JWT check должен быть выключен, а доступ проверяется в самом приложении:

- participant: Telegram `initData` HMAC;
- admin: `ADMIN_ACCESS_TOKEN`;
- screen: `SCREEN_ACCESS_TOKEN`;
- Telegram webhook: `TELEGRAM_WEBHOOK_SECRET`.

## Платежи

До подключения провайдера `TELEGRAM_PROVIDER_TOKEN` не задаётся. Для smoke test админ может выдать бесплатный тестовый билет пользователю, который уже один раз открыл Mini App.

Production payment включать только после теста платежа и возврата, статуса продавца и решения вопроса прав на публичный показ.

# Mini App UI map

## Bottom navigation MVP
1. Сегодня / ближайшее событие
2. Клуб (leaderboard shell)
3. Я (profile, ticket, history shell)

During an active event, a persistent primary card replaces normal home navigation and opens current stage.

## Event screen by status
SALES_OPEN -> hero + buy ticket + capacity + waitlist state
CHECKIN -> check-in + missing profile/consent
IDEAS_OPEN -> film idea form + countdown + submitted confirmation
TOP3_READY -> read-only finalists
IDEA_RANDOMIZED -> selected idea + reveal author
MOVIE_SEARCH -> animated Jipitina process; no fake terminal spam; show meaningful stages
MOVIE_FINALISTS -> 3 movie cards without revealing which will win until draw
MOVIE_SELECTED -> selected movie; admin availability lock
PREDICTIONS_OPEN -> 10 toggle cards; final Submit locks answers
WATCHING -> quiet black mode with 'film is running'
PREDICTIONS_SCORED -> personal score + winner
DISCUSSION -> short thought form after live conversation
FINAL_REVIEW -> rating + exactly one sentence
FEEDBACK -> compact survey
CLOSED -> result + next event CTA

## Admin
- event configuration: date/capacity/price/runtime cap
- open/close each stage
- one-click AI action with status and fallback
- live counts
- validate selected movie availability
- lock predictions
- mark actual prediction answers YES/NO/VOID
- see tie state
- approve AI synthesis
- close event
- export CSV/JSON

## Big screen
Separate browser route with no controls, realtime subscription, stage-specific full-screen composition.

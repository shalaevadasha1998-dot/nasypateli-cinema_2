# Backlog

## NOW — before 3 October
- venue search + outreach, max 5h, own drinks allowed, projector/sound/Wi‑Fi
- public screening rights workflow
- self-employed registration + YooKassa onboarding
- bot + Mini App technical MVP
- visual system: Насыпатели master -> НАСЫПАТЕЛИ В КИНО derivative
- Jipitina avatar/voice/personality bible
- Telegram channel launch
- Instagram + TikTok launch
- free distribution to relevant open Moscow groups/chats by interest
- content plan + shoot list
- dry run with 5–8 people
- physical collectible artifact prototype

## NEXT — after first event
- online blind watch; legal streaming model must be resolved before implementation
- participant profiles/history UI
- persistent leaderboard/achievements
- weekly secret ticket raffle
- participant directory / opt-in social discovery
- viewer × Jipitina review flow

## LATER
- paid membership/subscription
- personal AI cinema companion
- corporate versions
- standalone digital product

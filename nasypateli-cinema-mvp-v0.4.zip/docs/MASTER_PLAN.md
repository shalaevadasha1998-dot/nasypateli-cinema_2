# Master plan

## 1. Product hierarchy

### Brand
Насыпатели
  -> НАСЫПАТЕЛИ В КИНО
     -> офлайн «этого фильма не существует»
     -> онлайн blind watch (post-MVP)
     -> зритель × Джипитина (post-MVP)
     -> секретный билет (weekly promo, lightweight MVP-ready)

### Product principle
70% кино / 30% знакомства и тусовка. AI is a character and mechanism, not the main attraction.

## 2. MVP 3 October — must work
1. Telegram identity and onboarding.
2. Event page and ticket purchase.
3. Capacity configurable per event; automatic sold-out state; waitlist.
4. Cinema profile.
5. Consent to photo/video.
6. Anonymous film-idea submission.
7. AI top-3 selection with hidden author.
8. Cryptographically secure random pick.
9. AI candidate films + validation + <=150 min filter + top-3 + random pick.
10. 10 spoiler-safe yes/no predictions.
11. Lock answers before playback.
12. Admin enters actual answers after film; automatic scoring/tie detection.
13. Leaderboard points.
14. One short post-film thought per participant.
15. AI synthesis for screen.
16. Rating 1–10 + exactly one anonymous final sentence.
17. Auto-generated collective-review draft; manual approval before publication.
18. 3–6 question research survey.
19. Big-screen mode.
20. Admin mode + emergency fallbacks.

## 3. Not in MVP
- public participant directory
- full social graph / Tinder-like discovery
- free-form personal AI film critic chat
- paid membership/subscription
- online film streaming
- deep profile achievements
- automated social-post visual generation
- fully automated refunds without provider onboarding

Build DB hooks for these, but do not spend launch time on UI.

## 4. Roles
- Дора: product owner, host, final AI/content approval
- Иван: SMM/visual/content execution
- Илья: technical operator on event day; admin panel + playback + screen
- Джипитина: constrained AI persona; autonomous only inside explicit event actions

## 5. Launch metrics
Primary:
- tickets sold / capacity
- show-up rate
- >=70% 'would come again'

Mechanics health:
- profile completion
- idea submission rate
- predictions completion rate
- final-review completion rate
- median time per interactive stage
- AI failure / retry count

Research:
- strongest stage
- weakest/dragging stage
- willingness to pay next time: 500 / 700 / 900 / 1200 / >1200
- whether 4–5h felt too long
- whether they met someone they would talk to again
- whether they would invite a friend

Content:
- usable vertical clips
- usable reactions
- participant quotes with publication consent

## 6. Timeline to Wed 23 Sep (product-ready spec + technical skeleton)
- architecture / schema / prompts / UI map / state machine
- create bot and Mini App credentials (owner action)
- create Supabase project/env values (owner action)
- connect repo/deploy

Then 24 Sep–2 Oct:
- visual skin
- payment onboarding
- end-to-end rehearsal
- AI prompt tests
- venue + rights
- content launch
- dry run with 5–8 friends

## 7. Event-day failure policy
- AI timeout: use cached fallback generated during rehearsal or retry once on alternate cheap model
- movie provider unavailable: admin verifies from preloaded shortlist
- Mini App down: QR to emergency web form / paper tokens
- Telegram down: local admin export + manual ballots
- internet down: pre-generated 3 mock film branches and prediction sets
- payment down before event: manual invoice fallback; never improvise payment at door without tracking


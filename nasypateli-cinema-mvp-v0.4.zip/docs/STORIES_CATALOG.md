# НАСЫПАТЕЛИ В КИНО — STORY ENGINE v0.6

Ачивка здесь не цель. Каждая запись — история, которая должна быть интересна сама по себе; награда только оставляет след на Животине.

## Правила системы
- никакого XP за клики и бессмысленного гринда
- кинокрошки появляются только из реальных событий/историй
- 60% историй видимы, 25% показываются намёком, 15% скрыты
- каждая история меняет Животину: визуально, через характер/реплики или оба способа
- лимитированные истории нельзя получить задним числом
- исторические предметы не передаются между пользователями
- офлайн-подтверждение строится на event check-in, QR/NFC encounter token, взаимном подтверждении или организаторском действии

Каталог: **120 историй**, **45 визуальных следов первой библиотеки**.

| # | тип | история | редкость | видимость | системный триггер | что произошло | след на Животине |
|---:|---|---|---|---|---|---|---|
| 1 | cinema | НЕ ТОТ ФИЛЬМ | common | visible | `film_completed` | посмотрел фильм, который изначально вообще не собирался смотреть: выбор сделала случайность | + cinephile 2; +1 крош. |
| 2 | cinema | ПЕРЕДУМАЛ | common | visible | `reaction_saved` | оставил ожидание до просмотра и после фильма честно поменял мнение | + cinephile 2; +1 крош. |
| 3 | cinema | НЕ ПОНЯЛ, НО СМОТРЕЛ | uncommon | visible | `reaction_saved` | низко оценил понятность фильма, но высоко — впечатление | trace-didnt_understand_watched; + cinephile 3; +2 крош. |
| 4 | cinema | ДОСМОТРЕЛ ДО КОНЦА | common | visible | `reaction_saved` | киношная история: досмотрел до конца | + cinephile 2; +1 крош. |
| 5 | cinema | СТАРШЕ МЕНЯ | rare | visible | `reaction_saved` | киношная история: старше меня | + cinephile 5; +3 крош. |
| 6 | cinema | БЕЗ СЛОВ | uncommon | visible | `reaction_saved` | киношная история: без слов | trace-silent_night; + cinephile 3; +2 крош. |
| 7 | cinema | ДВА С ПОЛОВИНОЙ ЧАСА | common | visible | `reaction_saved` | киношная история: два с половиной часа | + cinephile 2; +1 крош. |
| 8 | cinema | ОДНА КОМНАТА | common | visible | `reaction_saved` | киношная история: одна комната | + cinephile 2; +1 крош. |
| 9 | cinema | СЮЖЕТ НЕ ПРИШЁЛ | uncommon | visible | `reaction_saved` | киношная история: сюжет не пришёл | trace-no_plot; + cinephile 3; +2 крош. |
| 10 | cinema | БЕЗ ДУБЛЯЖА | rare | visible | `reaction_saved` | киношная история: без дубляжа | + cinephile 5; +3 крош. |
| 11 | cinema | ДРУГАЯ СТРАНА | common | visible | `reaction_saved` | киношная история: другая страна | + cinephile 2; +1 крош. |
| 12 | cinema | МУЛЬТИК, ГОВОРИЛИ ОНИ | uncommon | visible | `reaction_saved` | киношная история: мультик, говорили они | trace-animation_is_cinema; + cinephile 3; +2 крош. |
| 13 | cinema | ЭТО ВООБЩЕ БЫЛО | common | visible | `reaction_saved` | киношная история: это вообще было | + cinephile 2; +1 крош. |
| 14 | cinema | ВТОРОЙ РАЗ — ДРУГОЕ КИНО | common | visible | `reaction_saved` | киношная история: второй раз — другое кино | + cinephile 2; +1 крош. |
| 15 | cinema | Я ТАК И ЗНАЛ | rare | visible | `prediction_scored` | киношная история: я так и знал | trace-prediction_perfect; + cinephile 5; +3 крош. |
| 16 | cinema | НИЧЕГО НЕ УГАДАЛ | common | visible | `prediction_scored` | киношная история: ничего не угадал | + cinephile 2; +1 крош. |
| 17 | cinema | ПРОТИВ ЗАЛА | common | visible | `reaction_saved` | киношная история: против зала | + cinephile 2; +1 крош. |
| 18 | cinema | КАК ВСЕ, И ЭТО НОРМАЛЬНО | uncommon | visible | `reaction_saved` | киношная история: как все, и это нормально | trace-rating_with_room; + cinephile 3; +2 крош. |
| 19 | cinema | Я ЭТОТ ЖАНР НЕ ЛЮБЛЮ | common | visible | `reaction_saved` | киношная история: я этот жанр не люблю | + cinephile 2; +1 крош. |
| 20 | cinema | ОДИН РЕЖИССЁР — ТРИ ФИЛЬМА | rare | visible | `film_completed` | киношная история: один режиссёр — три фильма | + cinephile 5; +3 крош. |
| 21 | cinema | ПО ЧУЖОМУ СОВЕТУ | uncommon | visible | `film_completed` | киношная история: по чужому совету | trace-film_after_recommendation; + cinephile 3; +2 крош. |
| 22 | cinema | ТРЕЙЛЕР ВРАЛ | common | visible | `reaction_saved` | киношная история: трейлер врал | + cinephile 2; +1 крош. |
| 23 | cinema | НЕ ЧИТАЛ ОПИСАНИЕ | common | visible | `reaction_saved` | киношная история: не читал описание | + cinephile 2; +1 крош. |
| 24 | cinema | НА УТРО НЕ ОТПУСТИЛ | uncommon | visible | `reaction_saved` | киношная история: на утро не отпустил | trace-morning_after; + cinephile 3; +2 крош. |
| 25 | random | КУДА МЕНЯ ЗАНЕСЛО | rare | hint | `random_task` | выполнил случайное офлайн-задание и оказался в сценарии, которого не планировал | random-bag; + chaotic 5; +3 крош. |
| 26 | random | ЧЕЛОВЕК ИЗ ОЧЕРЕДИ | common | hint | `random_task` | посмотрел фильм по совету случайного человека из очереди | + chaotic 2; +1 крош. |
| 27 | random | СЛУЧАЙНЫЙ СОУЧАСТНИК | uncommon | hint | `random_task` | выполнил совместное задание с незнакомым человеком, который получил ту же механику | trace-random_accomplice; + chaotic 3; +2 крош. |
| 28 | random | МОНЕТКА РЕШИЛА | common | hint | `random_task` | случайность внутри клуба: монетка решила | + chaotic 2; +1 крош. |
| 29 | random | ЖИВОТИНА РЕШИЛА | common | hint | `random_task` | случайность внутри клуба: животина решила | + chaotic 2; +1 крош. |
| 30 | random | НЕ В ТУ ДВЕРЬ | rare | secret | `random_task` | случайность внутри клуба: не в ту дверь | trace-wrong_door; + chaotic 5; +3 крош. |
| 31 | random | НЕ МОЁ МЕСТО | common | hint | `random_task` | случайность внутри клуба: не моё место | + chaotic 2; +1 крош. |
| 32 | random | КАРТОЧКА БЕЗ ОБЪЯСНЕНИЙ | common | secret | `random_task` | случайность внутри клуба: карточка без объяснений | + chaotic 2; +1 крош. |
| 33 | random | ТРИ СЛУЧАЙНОСТИ | uncommon | secret | `random_task` | случайность внутри клуба: три случайности | trace-three_randoms; + chaotic 3; +2 крош. |
| 34 | random | Я ЭТОГО НЕ ПЛАНИРОВАЛ | common | hint | `random_task` | случайность внутри клуба: я этого не планировал | + chaotic 2; +1 крош. |
| 35 | random | ЧУЖАЯ ПРОГРАММА | rare | hint | `random_task` | случайность внутри клуба: чужая программа | + chaotic 5; +3 крош. |
| 36 | random | КУБИК ВИНОВАТ | uncommon | hint | `random_task` | случайность внутри клуба: кубик виноват | trace-dice_night; + chaotic 3; +2 крош. |
| 37 | random | КИНО УВЕЛО ИЗ ДОМА | common | hint | `random_task` | случайность внутри клуба: кино увело из дома | + chaotic 2; +1 крош. |
| 38 | random | ЖАНР УЗНАЛ ПОТОМ | common | hint | `random_task` | случайность внутри клуба: жанр узнал потом | + chaotic 2; +1 крош. |
| 39 | random | ВЫБРАЛ ПРОТИВОПОЛОЖНОЕ | uncommon | hint | `random_task` | случайность внутри клуба: выбрал противоположное | trace-reverse_choice; + chaotic 3; +2 крош. |
| 40 | random | ЖИВОТИНА ПОДБИЛА | rare | hint | `random_task` | случайность внутри клуба: животина подбила | + chaotic 5; +3 крош. |
| 41 | random | НАЗАД НЕЛЬЗЯ | common | secret | `random_task` | случайность внутри клуба: назад нельзя | + chaotic 2; +1 крош. |
| 42 | random | ВТОРОЙ ФИЛЬМ СЛУЧИЛСЯ САМ | uncommon | hint | `random_task` | случайность внутри клуба: второй фильм случился сам | trace-surprise_double; + chaotic 3; +2 крош. |
| 43 | social | НЕЗНАКОМЕЦ | common | hint | `encounter` | впервые взаимодействовал с человеком, которого до этого не знал, через конкретное кино-задание | + social 2; +1 крош. |
| 44 | social | У НАС ОДИН ВКУС | common | hint | `encounter` | встретил человека с совпавшим любимым фильмом | + social 2; +1 крош. |
| 45 | social | У НАС НИЧЕГО ОБЩЕГО | rare | hint | `encounter` | встретил человека без совпадений по кино и всё равно сделал что-то вместе | trace-nothing_common; + social 5; +3 крош. |
| 46 | social | ПЕРЕУБЕДИЛ | common | hint | `social_task` | посмотрел фильм по рекомендации другого участника и изменил мнение о жанре, режиссёре или фильме | + social 2; +1 крош. |
| 47 | social | ЗАЙЦЫ ВСТРЕТИЛИСЬ | common | hint | `encounter` | история, которая произошла между людьми: зайцы встретились | + social 2; +1 крош. |
| 48 | social | ОДНА ОЦЕНКА | uncommon | hint | `encounter` | история, которая произошла между людьми: одна оценка | trace-same_rating; + social 3; +2 крош. |
| 49 | social | ДВА РАЗНЫХ ФИЛЬМА | common | hint | `encounter` | история, которая произошла между людьми: два разных фильма | + social 2; +1 крош. |
| 50 | social | ПОСОВЕТОВАЛ ТРЕТЬЕМУ | rare | hint | `social_task` | история, которая произошла между людьми: посоветовал третьему | + social 5; +3 крош. |
| 51 | social | ПРИШЁЛ ОДИН | uncommon | hint | `social_task` | история, которая произошла между людьми: пришёл один | trace-came_alone_left_group; + social 3; +2 крош. |
| 52 | social | ПРИВЁЛ НОВОГО | common | hint | `social_task` | история, которая произошла между людьми: привёл нового | + social 2; +1 крош. |
| 53 | social | ДОСПОРИЛИСЬ | common | hint | `social_task` | история, которая произошла между людьми: доспорились | + social 2; +1 крош. |
| 54 | social | ОБМЕНЯЛИСЬ ФИЛЬМАМИ | uncommon | hint | `social_task` | история, которая произошла между людьми: обменялись фильмами | trace-film_exchange; + social 3; +2 крош. |
| 55 | social | ТРИ ЗАЙЦА | rare | hint | `encounter` | история, которая произошла между людьми: три зайца | + social 5; +3 крош. |
| 56 | social | ОПЯТЬ ТЫ | common | hint | `encounter` | история, которая произошла между людьми: опять ты | + social 2; +1 крош. |
| 57 | social | МЫ ОПЯТЬ В ОДНОМ ЗАЛЕ | uncommon | secret | `encounter` | история, которая произошла между людьми: мы опять в одном зале | trace-same_event_three_times; + social 3; +2 крош. |
| 58 | social | ПОМОГ ВЫБРАТЬ | common | hint | `social_task` | история, которая произошла между людьми: помог выбрать | + social 2; +1 крош. |
| 59 | social | ОБЩИЙ СЕКРЕТ | common | secret | `encounter` | история, которая произошла между людьми: общий секрет | + social 2; +1 крош. |
| 60 | social | УНЕСЛИ ОДИН СЛЕД | rare | hint | `encounter` | история, которая произошла между людьми: унесли один след | trace-physical_token; + social 5; +3 крош. |
| 61 | dating | ПЕРВЫЙ ЛАЙК | common | visible | `dating_swipe` | история двух Животин: первый лайк | + romantic 2; +1 крош. |
| 62 | dating | ЗАЙЦЫ СОВПАЛИ | rare | visible | `dating_match` | два человека взаимно выбрали друг друга — их Животины впервые встретились | + romantic 5; +3 крош. |
| 63 | dating | МЭТЧ НА КИНО | uncommon | visible | `dating_match` | история двух Животин: мэтч на кино | trace-cinema_match; + romantic 3; +2 крош. |
| 64 | dating | ЗАЙЦЫ ПОДРУЖИЛИСЬ | common | visible | `dating_match` | история двух Животин: зайцы подружились | + romantic 2; +1 крош. |
| 65 | dating | ЭТО УЖЕ ПОХОЖЕ НА СВИДАНИЕ | rare | visible | `dating_match` | история двух Животин: это уже похоже на свидание | + romantic 5; +3 крош. |
| 66 | dating | ПРОТИВОПОЛОЖНОСТИ | uncommon | secret | `dating_match` | история двух Животин: противоположности | trace-opposites_match; + romantic 3; +2 крош. |
| 67 | dating | ОДИН ЛЮБИМЫЙ ФИЛЬМ | common | visible | `dating_match` | история двух Животин: один любимый фильм | + romantic 2; +1 крош. |
| 68 | dating | ПОСМОТРЕЛИ ВМЕСТЕ | common | visible | `dating_match` | история двух Животин: посмотрели вместе | + romantic 2; +1 крош. |
| 69 | dating | ВТОРОЙ ВЕЧЕР ВМЕСТЕ | uncommon | visible | `dating_swipe` | история двух Животин: второй вечер вместе | trace-second_shared_event; + romantic 3; +2 крош. |
| 70 | dating | ЭТО УЖЕ СИСТЕМА | rare | visible | `dating_swipe` | история двух Животин: это уже система | + romantic 5; +3 крош. |
| 71 | dating | ТРИ СОВПАДЕНИЯ | common | secret | `dating_match` | история двух Животин: три совпадения | + romantic 2; +1 крош. |
| 72 | dating | ЖИВОТИНА НАС ПОЗНАКОМИЛА | rare | visible | `dating_match` | мэтч появился после рекомендации Животины-свахи | trace-jipitina_match; + romantic 5; +3 крош. |
| 73 | dating | СЛУЧАЙНОЕ СВИДАНИЕ | rare | visible | `dating_match` | история двух Животин: случайное свидание | + romantic 5; +3 крош. |
| 74 | dating | СНАЧАЛА ЗАЯЦ | common | visible | `dating_swipe` | история двух Животин: сначала заяц | + romantic 2; +1 крош. |
| 75 | dating | ЛЮБИМ РАЗНОЕ | rare | visible | `dating_match` | история двух Животин: любим разное | trace-different_genres_match; + romantic 5; +3 крош. |
| 76 | dating | НЕНАВИДИМ ОДНО И ТО ЖЕ | common | visible | `dating_match` | история двух Животин: ненавидим одно и то же | + romantic 2; +1 крош. |
| 77 | dating | ВЫБРАЛИ ДРУГ ДРУГУ | common | visible | `dating_swipe` | история двух Животин: выбрали друг другу | + romantic 2; +1 крош. |
| 78 | dating | СНОВА НАШЛИСЬ | uncommon | visible | `dating_match` | история двух Животин: снова нашлись | trace-match_reconnected; + romantic 3; +2 крош. |
| 79 | dating | ДВА МЭТЧА ЗА ВЕЧЕР | common | visible | `dating_match` | история двух Животин: два мэтча за вечер | + romantic 2; +1 крош. |
| 80 | dating | ЕСТЬ С КЕМ ИДТИ | rare | visible | `dating_match` | история двух Животин: есть с кем идти | + romantic 5; +3 крош. |
| 81 | dating | ГОД НАЗАД ЗАЙЦЫ ВСТРЕТИЛИСЬ | legendary | visible | `dating_match` | история двух Животин: год назад зайцы встретились | trace-match_anniversary; + romantic 8; +5 крош. |
| 82 | dating | ЖИВОТИНА-СВАХА | common | visible | `dating_match` | история двух Животин: животина-сваха | + romantic 2; +1 крош. |
| 83 | jipitina | ЗАЙЧИК, ТЫ НЕ ПРАВ | common | visible | `jipitina_chat` | реально поспорил с Животиной о фильме и развил спор дальше одного сообщения | + argumentative 2; +1 крош. |
| 84 | jipitina | МЫ СОШЛИСЬ | uncommon | visible | `jipitina_chat` | независимо от Животины выбрал тот же фильм | trace-we_agreed; + argumentative 3; +2 крош. |
| 85 | jipitina | ЖИВОТИНА МЕНЯ ЗНАЕТ | rare | visible | `jipitina_chat` | доверил выбор Животине, посмотрел и подтвердил, что она попала во вкус | + argumentative 5; +3 крош. |
| 86 | jipitina | ЖИВОТИНА МЕНЯ НЕ ЗНАЕТ | common | visible | `jipitina_chat` | Животина промахнулась с рекомендацией, а пользователь объяснил почему — профиль вкуса обновился | + argumentative 2; +1 крош. |
| 87 | jipitina | ПЕРВЫЙ СПОР | uncommon | visible | `jipitina_chat` | история отношений с собственной Животиной: первый спор | trace-first_argument; + argumentative 3; +2 крош. |
| 88 | jipitina | ПЕРЕУБЕДИЛ ЖИВОТИНУ | common | visible | `jipitina_chat` | история отношений с собственной Животиной: переубедил животину | + argumentative 2; +1 крош. |
| 89 | jipitina | ЖИВОТИНА ПЕРЕУБЕДИЛА МЕНЯ | common | visible | `jipitina_chat` | история отношений с собственной Животиной: животина переубедила меня | + argumentative 2; +1 крош. |
| 90 | jipitina | УДИВИ МЕНЯ | rare | visible | `jipitina_chat` | история отношений с собственной Животиной: удиви меня | trace-asked_for_surprise; + argumentative 5; +3 крош. |
| 91 | jipitina | Я ТЕБЕ ДОВЕРЯЮ | common | visible | `jipitina_chat` | история отношений с собственной Животиной: я тебе доверяю | + argumentative 2; +1 крош. |
| 92 | jipitina | НЕТ, НЕТ И ЕЩЁ РАЗ НЕТ | common | visible | `jipitina_chat` | история отношений с собственной Животиной: нет, нет и ещё раз нет | + argumentative 2; +1 крош. |
| 93 | jipitina | НАСТРОИЛИ ВКУС | uncommon | visible | `jipitina_chat` | история отношений с собственной Животиной: настроили вкус | trace-taste_calibrated; + argumentative 3; +2 крош. |
| 94 | jipitina | ОНА УГАДАЛА ОЦЕНКУ | common | visible | `reaction_saved` | история отношений с собственной Животиной: она угадала оценку | + argumentative 2; +1 крош. |
| 95 | jipitina | ОНА НЕ УГАДАЛА ВООБЩЕ | rare | visible | `reaction_saved` | история отношений с собственной Животиной: она не угадала вообще | + argumentative 5; +3 крош. |
| 96 | jipitina | НОЧНОЙ РАЗГОВОР | uncommon | visible | `jipitina_chat` | история отношений с собственной Животиной: ночной разговор | trace-late_night_chat; + argumentative 3; +2 крош. |
| 97 | jipitina | МЫ УЖЕ ЗНАКОМЫ | common | visible | `jipitina_chat` | история отношений с собственной Животиной: мы уже знакомы | + argumentative 2; +1 крош. |
| 98 | jipitina | ЖИВОТИНА ЧТО-ТО СКРЫВАЕТ | common | secret | `jipitina_chat` | история отношений с собственной Животиной: животина что-то скрывает | + argumentative 2; +1 крош. |
| 99 | seasonal | ПЕРВООТКРЫВАТЕЛЬ | legendary | visible | `event_checkin` | пришёл на самый первый публичный вечер НАСЫПАТЕЛЕЙ В КИНО | first-flower; + curiosity 8; +5 крош. |
| 100 | seasonal | ПЕРВЫЕ 30 | legendary | visible | `event_checkin` | оказался среди первых тридцати участников проекта | trace-first_thirty; + curiosity 8; +5 крош. |
| 101 | seasonal | ХЭЛЛОУИН | legendary | visible | `event_checkin` | пришёл на лимитированный хэллоуинский показ | horror-fangs; + curiosity 8; +5 крош. |
| 102 | seasonal | ПОСЛЕДНИЙ ЗРИТЕЛЬ | rare | secret | `event_checkin` | лимитированная история конкретного периода проекта: последний зритель | trace-halloween_last_viewer; + curiosity 5; +3 крош. |
| 103 | seasonal | НАЧАЛО | common | visible | `event_checkin` | лимитированная история конкретного периода проекта: начало | + curiosity 2; +1 крош. |
| 104 | seasonal | СЛУЧАЙНЫЙ ФИЛЬМ | common | visible | `event_checkin` | лимитированная история конкретного периода проекта: случайный фильм | + curiosity 2; +1 крош. |
| 105 | seasonal | СЕМЬ ДНЕЙ | legendary | visible | `event_checkin` | прошёл все семь дней новогоднего киномарафона | scarf-red; + curiosity 8; +5 крош. |
| 106 | seasonal | СВИДАНИЕ С НЕЗНАКОМЦЕМ | legendary | visible | `event_checkin` | согласился на кино-встречу с незнакомым человеком через механику проекта | romantic-heart; + curiosity 8; +5 крош. |
| 107 | seasonal | НЕ СВИДАНИЕ | common | visible | `event_checkin` | лимитированная история конкретного периода проекта: не свидание | + curiosity 2; +1 крош. |
| 108 | seasonal | ТРЕТИЙ ЛИШНИЙ | uncommon | visible | `event_checkin` | лимитированная история конкретного периода проекта: третий лишний | trace-valentine_third; + curiosity 3; +2 крош. |
| 109 | seasonal | УЕХАЛ ЗА КИНО | common | visible | `event_checkin` | лимитированная история конкретного периода проекта: уехал за кино | + curiosity 2; +1 крош. |
| 110 | seasonal | КИНО ПОД ОТКРЫТЫМ НЕБОМ | rare | visible | `event_checkin` | лимитированная история конкретного периода проекта: кино под открытым небом | + curiosity 5; +3 крош. |
| 111 | seasonal | ДРУГОЙ ГОРОД | legendary | visible | `event_checkin` | лимитированная история конкретного периода проекта: другой город | travel-ticket; + curiosity 8; +5 крош. |
| 112 | seasonal | SEASON 0 | legendary | visible | `event_checkin` | лимитированная история конкретного периода проекта: season 0 | trace-season_zero; + curiosity 8; +5 крош. |
| 113 | secret | ПЯТЬ МИНУТ ДО | common | secret | `event_checkin` | трижды пришёл на событие за пять минут до начала | + curiosity 2; +1 крош. |
| 114 | secret | НЕ СПАЛ | rare | secret | `event_checkin` | был на ночном показе и вернулся на утренний | night-cap; + curiosity 5; +3 крош. |
| 115 | secret | ЭТО БЫЛО СЛУЧАЙНО | rare | secret | `manual_story` | секретная история, которую нельзя специально фармить: это было случайно | + curiosity 5; +3 крош. |
| 116 | secret | ЖИВОТИНА В ШОКЕ | rare | secret | `manual_story` | оценка фильма оказалась настолько далека от прогноза Животины, что её модель вкуса заметно перестроилась | + curiosity 5; +3 крош. |
| 117 | secret | ПОСЛЕДНИЙ БИЛЕТ | rare | secret | `ticket_paid` | купил одно из последних мест на событие | trace-last_ticket; + curiosity 5; +3 крош. |
| 118 | secret | Я ОСТАЛСЯ | rare | secret | `manual_story` | остался после фильма на продолжение вечера, хотя изначально собирался уйти | + curiosity 5; +3 крош. |
| 119 | secret | А Я ДУМАЛ, ТЫ ДОМОЙ | rare | secret | `event_checkin` | секретная история, которую нельзя специально фармить: а я думал, ты домой | + curiosity 5; +3 крош. |
| 120 | secret | ОДИН ИЗ ОДНОГО | mythic | secret | `manual_story` | получил уникальную одноэкземплярную историю конкретного вечера | trace-one_of_one; + curiosity 12; +8 крош. |
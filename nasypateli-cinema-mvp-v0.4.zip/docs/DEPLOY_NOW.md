# Deploy now — самый короткий путь

На первом MVP GitHub и Cloudflare не нужны для запуска. Один Supabase Edge Function `app` одновременно отдаёт:

- Telegram Mini App;
- API;
- админку;
- экран проектора;
- Telegram webhook;
- invoice endpoint.

Production URL:

`https://vwteokawtqnoiyzmsldj.supabase.co/functions/v1/app`

## 1. Обновить уже созданную базу

В Supabase → SQL Editor выполнить целиком `supabase/PATCH_V0_4.sql`.

Патч добавляет атомарное резервирование мест и поле победителя. Его можно запускать повторно.

## 2. Добавить secrets

Supabase → Edge Functions → Secrets. Значения лежат в отдельном PRIVATE setup-файле, который не входит в GitHub/zip проекта.

Обязательны до первого реального теста:

- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_WEBAPP_URL`
- `TELEGRAM_WEBHOOK_SECRET`
- `OPENAI_API_KEY`
- `OPENAI_MODEL=gpt-5.6-luna`
- `OPENAI_FILM_MODEL=gpt-5.6-terra`
- `ALLOW_DEMO_AUTH=false`
- `ADMIN_ACCESS_TOKEN`
- `SCREEN_ACCESS_TOKEN`

`TELEGRAM_PROVIDER_TOKEN` пока не нужен. До подключения провайдера тестовым участникам билет можно выдавать из админки по Telegram username.

## 3. Deploy одной Edge Function

Supabase → Edge Functions → Deploy a new function → Via Editor.

Перетащить `nasypateli-supabase-app.zip`, указать имя функции `app`, Deploy.

Для функции `app` отключить built-in JWT verification. Приложение само проверяет Telegram initData, admin token, screen token и webhook secret.

## 4. Открыть админку

Использовать приватную admin URL из `nasypateli-private-setup.txt`. Ключ передаётся во fragment `#key=...`, поэтому не отправляется серверу и после первого открытия убирается из адреса, оставаясь в sessionStorage текущей вкладки.

В админке нажать:

`подключить webhook + кнопку меню`

Это автоматически:

- устанавливает webhook на `?mode=telegram`;
- создаёт кнопку «открыть клуб» у бота;
- устанавливает команды `/start` и `/paysupport`.

## 5. Smoke test без оплаты

1. Участник открывает `@nasipateli_v_kinobot` → `/start` → «открыть клуб».
2. После первого открытия его Telegram user появляется в базе.
3. В админке в «тестовые билеты» ввести `@username` и выдать бесплатный тестовый билет.
4. Открыть приватную screen URL на ноутбуке/проекторе.
5. Прогнать механику до конца.

## 6. Перед продажами

Только после подключения платёжного провайдера добавить `TELEGRAM_PROVIDER_TOKEN` и проверить тестовый платёж/возврат. Отдельно решить право на публичный показ фильма.

# Текущее состояние проекта

Обновлено: 20 сентября 2026.

## Уже готово

- Supabase project: `vwteokawtqnoiyzmsldj`
- базовая SQL-схема выполнена владельцем проекта
- `supabase/PATCH_V0_4.sql` подготовлен: атомарная резервация мест + winner_user_id; его ещё нужно выполнить в SQL Editor
- Telegram bot: `@nasipateli_v_kinobot`
- GitHub repo: `shalaevadasha1998-dot/nasypateli-cinema_2`
- единый backend: `supabase/functions/app`
- Mini App participant/admin/screen UI
- demo-mode без внешних сервисов

## Следующий технический рубеж

1. положить секреты в Supabase Edge Functions Secrets — не в GitHub
2. deploy `app`
3. deploy `web/` на Cloudflare Pages
4. записать production URL в `TELEGRAM_WEBAPP_URL`
5. установить webhook со случайным `TELEGRAM_WEBHOOK_SECRET`
6. добавить Menu Button / Mini App URL в BotFather
7. пройти smoke-test с реального Telegram аккаунта

## До продаж

Платежи не включать до подключения провайдера, тестового платежа/возврата и решения вопроса прав на публичный показ фильма.

## GitHub доступ

Репозиторий `shalaevadasha1998-dot/nasypateli-cinema_2` публично читается, но GitHub App/connector пока не установлен ни на один репозиторий (`installations=[]`), поэтому автоматический push из ChatGPT сейчас получает 403. После выдачи connector access код можно загрузить без ручного копирования файлов.

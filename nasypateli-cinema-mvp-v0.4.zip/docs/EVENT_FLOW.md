# Event state machine and screen behavior

Each state has: participant UI, admin action, big-screen output, persisted artifact.

1. CHECKIN
Participant: open app, confirm presence, complete missing profile/consent.
Admin: live headcount.
Screen: animated arrival counter, no personal names unless opted in.

2. IDEAS_OPEN
Participant: title (5–7 words max target) + plot (500 chars hard limit).
Admin: timer + submission count only.
Screen: countdown / number of submitted films.

3. TOP3_READY
AI receives submissions without author identifiers plus aggregate profiles.
AI returns exactly 3 ids + short one-line reason for each.
Screen: reveal 3 ideas.

4. IDEA_RANDOMIZED
Server uses crypto random selection among 3 and logs the result.
Only after result: author id is fetched and may be revealed.

5. MOVIE_SEARCH
AI receives selected idea + aggregate audience profile.
It proposes 10–15 real candidates with title/year and reason.
Validator confirms existence and runtime <=150 min.
AI reranks validated list: 70% similarity to idea, 30% audience fit.
Exactly 3 finalists stored.

6. MOVIE_SELECTED
Server randomly selects 1 finalist. Availability/manual technical check is required before final lock; if impossible, next randomized candidate can be activated and reason logged.

7. PREDICTIONS_OPEN
AI generates exactly 10 spoiler-safe binary statements.
No character names, actor names or explicit plot twists.
Participants answer YES/NO.
Admin locks before playback.

8. WATCHING
Participant app becomes intentionally quiet. No game interruptions.
Screen goes black / film output takes over.

9. PREDICTIONS_SCORED
Admin marks ground truth for each question YES/NO/VOID.
Scores computed automatically. VOID removed from denominator.
Ties -> host starts fallback tie-breaker.

10. DISCUSSION
No forced app usage initially.
Then each participant sends one short thought (MVP: <=240 chars).
AI synthesizes consensus, disagreements, interesting arguments, one point it disputes, and its own rating.

11. FINAL_REVIEW
Participant submits rating 1–10 + exactly one anonymous final sentence <=180 chars.
No editing after submit.

12. FEEDBACK
Short research survey.

13. CLOSED
Draft publication package generated: movie, mean rating, verbatim final sentences, selected event stats and suggested layout copy. Human approves.

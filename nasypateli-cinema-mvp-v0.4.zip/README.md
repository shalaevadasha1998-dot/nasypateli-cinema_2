# НАСЫПАТЕЛИ В КИНО — MVP v0.6

Рабочий MVP киноклуба для первого офлайна 3 октября 2026.

## Что уже реализовано в коде

- production no-build Mini App UI прямо из Supabase Edge Function + React/Vite версия для дальнейшей разработки
- защищённая web-админка для Ильи по `?view=admin`
- защищённый fullscreen-экран проектора по `?view=screen`
- demo mode без ключей и внешних сервисов
- Supabase schema + seed первого события
- Telegram initData server-side validation
- Telegram Bot webhook `/start`, `/paysupport`, защищённый webhook, PreCheckoutQuery, SuccessfulPayment
- Telegram invoice link + 15-минутная резервация места + waitlist + повторная проверка резерва перед оплатой
- configurable capacity
- заявки несуществующих фильмов
- GPT top-3 идей
- криптографический random draw с сохранением random bytes
- GPT movie candidates + Wikidata validation + runtime <=150 минут
- random movie draw
- GPT 10 predictions
- ответы «будет / не будет» + admin fact check + scoring
- discussion thoughts
- Джипитина: post-film synthesis
- rating + дословная финальная фраза
- draft коллективной рецензии с ручным approval
- feedback survey
- persistent club memory для Джипитины
- RLS на таблицах; клиенты не получают service/secret key

## v0.6 — Животина

- каноническая зелёная Животина как персональная GPT и социальный аватар
- birth flow из коробки попкорна + Telegram accelerometer/haptic + tap fallback
- рост tiny → young → grown без наказаний за отсутствие
- кинокрошки + ledger без click-grind
- story engine на 120 историй, 45 стартовых визуальных следов, rarity/visibility/secret/limited logic
- timeline истории Животины и гардероб
- dating opt-in 18+: свайпы Животин, mutual match, friend/cinema/romantic connections, hide/block
- QR/NFC-compatible encounter tokens и event check-in token
- отдельная нижняя кнопка Животины/Джипитины, знакомства, архив
- voice input через OpenAI transcription
- optimistic chat, короткий low-latency GPT-5.6 Luna response, background memory/story extraction
- настройки Telegram notifications + notification queue + cron dispatcher endpoint
- удаление персонального профиля с сохранением минимальных билетных/платёжных записей
- дизайн-система из канонического логотипа: black / rabbit green / eye red / warm white

Перед deploy v0.6 сначала выполнить `supabase/PATCH_V0_6.sql`, затем обновить Edge Function и frontend.

## Самый быстрый тест без настройки

Откройте `demo/index.html` в браузере или:

```bash
./scripts-run-demo.sh
```

Дальше см. `docs/LAUNCH.md`.

## Структура

- `supabase/functions/app/ui.ts` — production Mini App/admin/screen без отдельного хостинга
- `web/` — React/Vite версия для следующей итерации
- `supabase/schema.sql` — база
- `supabase/seed.sql` — событие 3 октября
- `supabase/functions/app/` — единый backend: Mini App API + Telegram webhook + платежный invoice
- `demo/` — no-dependency smoke test
- `prompts/` — исходные prompt specs
- `docs/` — продуктовая архитектура и запуск

## Что требует владельца аккаунта

Только внешние секреты/регистрации: токен уже созданного бота `@nasipateli_v_kinobot`, OpenAI API key и позже платёжный провайдер. Supabase project уже создан и привязан в конфиге. Секреты не коммитить в GitHub.


Самый короткий production deploy: `docs/DEPLOY_NOW.md`.

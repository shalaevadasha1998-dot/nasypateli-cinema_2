# Насыпатели в кино — MVP v0.4

Рабочий MVP киноклуба для первого офлайна 3 октября 2026.

## Что уже реализовано в коде

- production no-build Mini App UI прямо из Supabase Edge Function + React/Vite версия для дальнейшей разработки
- защищённая web-админка для Ильи по `?view=admin`
- защищённый fullscreen-экран проектора по `?view=screen`
- demo mode без ключей и внешних сервисов
- Supabase schema + seed первого события
- Telegram initData server-side validation
- Telegram Bot webhook `/start`, `/paysupport`, защищённый webhook, PreCheckoutQuery, SuccessfulPayment
- Telegram invoice link + 15-минутная резервация места + waitlist + повторная проверка резерва перед оплатой
- configurable capacity
- заявки несуществующих фильмов
- GPT top-3 идей
- криптографический random draw с сохранением random bytes
- GPT movie candidates + Wikidata validation + runtime <=150 минут
- random movie draw
- GPT 10 predictions
- ответы «будет / не будет» + admin fact check + scoring
- discussion thoughts
- Джипитина: post-film synthesis
- rating + дословная финальная фраза
- draft коллективной рецензии с ручным approval
- feedback survey
- persistent club memory для Джипитины
- RLS на таблицах; клиенты не получают service/secret key

## Самый быстрый тест без настройки

Откройте `demo/index.html` в браузере или:

```bash
./scripts-run-demo.sh
```

Дальше см. `docs/LAUNCH.md`.

## Структура

- `supabase/functions/app/ui.ts` — production Mini App/admin/screen без отдельного хостинга
- `web/` — React/Vite версия для следующей итерации
- `supabase/schema.sql` — база
- `supabase/seed.sql` — событие 3 октября
- `supabase/functions/app/` — единый backend: Mini App API + Telegram webhook + платежный invoice
- `demo/` — no-dependency smoke test
- `prompts/` — исходные prompt specs
- `docs/` — продуктовая архитектура и запуск

## Что требует владельца аккаунта

Только внешние секреты/регистрации: токен уже созданного бота `@nasipateli_v_kinobot`, OpenAI API key и позже платёжный провайдер. Supabase project уже создан и привязан в конфиге. Секреты не коммитить в GitHub.


Самый короткий production deploy: `docs/DEPLOY_NOW.md`.

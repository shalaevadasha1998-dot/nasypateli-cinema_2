import { adminDb } from '../_shared/db.ts'
import { cors, err, json } from '../_shared/http.ts'
import { telegramUserFromRequest, isConfiguredAdmin } from '../_shared/telegram.ts'
import { secureIndex } from '../_shared/random.ts'
import { structuredResponse } from '../_shared/openai.ts'
import { JIPITINA } from '../_shared/jipitina.ts'
import { validateMovieTitle } from '../_shared/movies.ts'
import { buildEventState, eventBySlug, nextEvent } from '../_shared/state.ts'

const manualTransitions:Record<string,string>={
  DRAFT:'SALES_OPEN',SALES_OPEN:'CHECKIN',CHECKIN:'IDEAS_OPEN',IDEAS_OPEN:'IDEAS_LOCKED',PREDICTIONS_OPEN:'PREDICTIONS_LOCKED',PREDICTIONS_LOCKED:'WATCHING',PREDICTIONS_SCORED:'DISCUSSION',DISCUSSION:'FINAL_REVIEW',FINAL_REVIEW:'FEEDBACK',FEEDBACK:'CLOSED'
}

async function getOrCreateUser(db:any,tg:any){
  const existing=await db.from('users').select('*').eq('telegram_id',tg.id).maybeSingle()
  if(existing.data) return existing.data
  const created=await db.from('users').insert({telegram_id:tg.id,telegram_username:tg.username||null,display_name:[tg.first_name,tg.last_name].filter(Boolean).join(' ')||null}).select('*').single()
  if(created.error) throw created.error
  return created.data
}
async function mustAdmin(db:any,user:any,tg:any){if(isConfiguredAdmin(tg))return;const r=await db.from('admins').select('role').eq('user_id',user.id).maybeSingle();if(!r.data)throw new Error('Admin access required')}
async function hasPaidAccess(db:any,eventId:string,userId:string){const r=await db.from('registrations').select('status').eq('event_id',eventId).eq('user_id',userId).maybeSingle();if(r.error)throw r.error;return ['paid','attended'].includes(r.data?.status||'')}

function tokenMatches(req:Request,header:string,envName:string){
  const expected=Deno.env.get(envName)||''
  const got=req.headers.get(header)||''
  if(!expected||!got||expected.length!==got.length)return false
  let diff=0
  for(let i=0;i<expected.length;i++)diff|=expected.charCodeAt(i)^got.charCodeAt(i)
  return diff===0
}

async function telegramBot(method:string,body:Record<string,unknown>){
  const token=Deno.env.get('TELEGRAM_BOT_TOKEN')
  if(!token)throw new Error('TELEGRAM_BOT_TOKEN missing')
  const r=await fetch(`https://api.telegram.org/bot${token}/${method}`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)})
  const j=await r.json()
  if(!j.ok)throw new Error(j.description||method)
  return j.result
}

async function refreshLeaderboard(db:any,userIds:string[]){
  for(const uid of [...new Set(userIds)]){
    const scores=await db.from('event_scores').select('points').eq('user_id',uid)
    if(scores.error)throw scores.error
    const wins=await db.from('events').select('*',{count:'exact',head:true}).eq('winner_user_id',uid)
    if(wins.error)throw wins.error
    await db.from('leaderboard').upsert({user_id:uid,events_attended:(scores.data||[]).length,prediction_points:(scores.data||[]).reduce((n:number,x:any)=>n+Number(x.points||0),0),wins:wins.count||0,updated_at:new Date().toISOString()})
  }
}

export async function handleApi(req:Request){
  if(req.method==='OPTIONS')return new Response('ok',{headers:cors})
  if(req.method!=='POST')return err('POST only',405)
  try{
    const body=await req.json(); const action=String(body.action||'')
    const db=adminDb()
    const adminTokenOk=tokenMatches(req,'x-admin-token','ADMIN_ACCESS_TOKEN')
    const screenTokenOk=tokenMatches(req,'x-screen-token','SCREEN_ACCESS_TOKEN')

    if(action==='health')return json({ok:true,version:'0.4.0',service:'nasypateli-cinema'})

    if(action==='screen-bootstrap'){
      if(!screenTokenOk)return err('Screen access denied',401)
      const event=await eventBySlug(db,String(body.slug||'2026-10-03'))
      return json(await buildEventState(db,event,{includeActuals:false}))
    }
    if(action==='admin-bootstrap'){
      if(!adminTokenOk)return err('Admin access denied',401)
      const event=await eventBySlug(db,String(body.slug||'2026-10-03'))
      return json(await buildEventState(db,event,{includeActuals:true}))
    }

    const isAdminAction=action.startsWith('admin-')||action.startsWith('ai-')||action.startsWith('draw-')
    let tg:any=null,user:any=null
    if(!isAdminAction||!adminTokenOk){
      tg=await telegramUserFromRequest(req)
      user=await getOrCreateUser(db,tg)
    }

    if(action==='bootstrap'){
      const event=await nextEvent(db)
      if(!event)return json({user,profile:null,event:null})
      const common=await buildEventState(db,event,{includeActuals:false})
      const [profile,reg,idea,answers,thought,review,feedback]=await Promise.all([
        db.from('cinema_profiles').select('*').eq('user_id',user.id).maybeSingle(),
        db.from('registrations').select('*').eq('event_id',event.id).eq('user_id',user.id).maybeSingle(),
        db.from('film_ideas').select('id,title,plot').eq('event_id',event.id).eq('user_id',user.id).maybeSingle(),
        db.from('prediction_answers').select('question_id,answer').eq('event_id',event.id).eq('user_id',user.id),
        db.from('discussion_thoughts').select('text').eq('event_id',event.id).eq('user_id',user.id).maybeSingle(),
        db.from('final_reviews').select('rating,final_sentence').eq('event_id',event.id).eq('user_id',user.id).maybeSingle(),
        db.from('event_feedback').select('*').eq('event_id',event.id).eq('user_id',user.id).maybeSingle()
      ])
      for(const r of [profile,reg,idea,answers,thought,review,feedback]) if(r.error)throw r.error
      const answerMap=new Map((answers.data||[]).map((x:any)=>[x.question_id,x.answer]))
      return json({
        ...common,user,
        profile:profile.data?{displayName:user.display_name||'',favoriteFilms:(profile.data.favorite_films||[]).join(', '),favoriteGenres:(profile.data.favorite_genres||[]).join(', '),avoid:(profile.data.avoid||[]).join(', '),photoVideoConsent:reg.data?.photo_video_consent??profile.data?.profile_json?.photo_video_consent??false}:{displayName:user.display_name||'',favoriteFilms:'',favoriteGenres:'',avoid:'',photoVideoConsent:false},
        registration:reg.data?.status||'none',idea:idea.data||undefined,
        predictions:(common.predictions||[]).map((p:any)=>({...p,answer:answerMap.get(p.id)})),predictionSubmitted:(answers.data||[]).length>0,
        thought:thought.data?.text,review:review.data?{rating:review.data.rating,sentence:review.data.final_sentence}:undefined,
        feedback:feedback.data?{returnIntent:feedback.data.return_intent,strongest:feedback.data.strongest_part||'',improve:feedback.data.improve_text||'',willingness:feedback.data.willingness_to_pay||0,durationFeel:feedback.data.duration_feel||'нормально',inviteFriend:feedback.data.invite_friend===null||feedback.data.invite_friend===undefined?8:Number(feedback.data.invite_friend)}:undefined
      })
    }

    if(action==='save-profile'){
      const p=body.profile||{}; const split=(x:any)=>String(x||'').split(',').map((s:string)=>s.trim()).filter(Boolean)
      await db.from('users').update({display_name:String(p.displayName||'').slice(0,80),updated_at:new Date().toISOString()}).eq('id',user.id)
      const up=await db.from('cinema_profiles').upsert({user_id:user.id,favorite_films:split(p.favoriteFilms),favorite_genres:split(p.favoriteGenres),avoid:split(p.avoid),profile_json:{photo_video_consent:!!p.photoVideoConsent},updated_at:new Date().toISOString()});if(up.error)throw up.error
      const ev=await db.from('events').select('id').order('starts_at',{ascending:true}).limit(1).maybeSingle();if(ev.data)await db.from('registrations').update({photo_video_consent:!!p.photoVideoConsent}).eq('event_id',ev.data.id).eq('user_id',user.id)
      return json({ok:true})
    }

    const slug=String(body.slug||'2026-10-03'); const event=await eventBySlug(db,slug)

    if(action==='submit-idea'){
      if(!await hasPaidAccess(db,event.id,user.id))return err('Paid ticket required',403)
      if(event.status!=='IDEAS_OPEN')return err('Ideas are closed',409)
      const title=String(body.title||'').trim(),plot=String(body.plot||'').trim();if(!title||!plot)return err('Title and plot required')
      const r=await db.from('film_ideas').upsert({event_id:event.id,user_id:user.id,title:title.slice(0,100),plot:plot.slice(0,500)},{onConflict:'event_id,user_id'});if(r.error)throw r.error;return json({ok:true})
    }
    if(action==='submit-predictions'){
      if(!await hasPaidAccess(db,event.id,user.id))return err('Paid ticket required',403)
      if(event.status!=='PREDICTIONS_OPEN')return err('Predictions are closed',409)
      const list=Array.isArray(body.predictions)?body.predictions:[];if(list.length!==10||list.some((x:any)=>typeof x.answer!=='boolean'))return err('Exactly 10 boolean predictions required')
      const rows=list.map((x:any)=>({event_id:event.id,question_id:x.id,user_id:user.id,answer:x.answer}));const r=await db.from('prediction_answers').upsert(rows);if(r.error)throw r.error;return json({ok:true})
    }
    if(action==='submit-thought'){
      if(!await hasPaidAccess(db,event.id,user.id))return err('Paid ticket required',403)
      if(event.status!=='DISCUSSION')return err('Discussion input is closed',409)
      const r=await db.from('discussion_thoughts').upsert({event_id:event.id,user_id:user.id,text:String(body.text||'').slice(0,240)});if(r.error)throw r.error;return json({ok:true})
    }
    if(action==='submit-review'){
      if(!await hasPaidAccess(db,event.id,user.id))return err('Paid ticket required',403)
      if(event.status!=='FINAL_REVIEW')return err('Review input is closed',409)
      const rating=Number(body.rating);if(!Number.isInteger(rating)||rating<1||rating>10)return err('Rating must be an integer from 1 to 10');const sentence=String(body.sentence||'').trim();if(!sentence)return err('Final sentence required');const r=await db.from('final_reviews').upsert({event_id:event.id,user_id:user.id,rating,final_sentence:sentence.slice(0,180)});if(r.error)throw r.error;return json({ok:true})
    }
    if(action==='submit-feedback'){
      if(!await hasPaidAccess(db,event.id,user.id))return err('Paid ticket required',403)
      if(!['FEEDBACK','CLOSED'].includes(event.status))return err('Feedback is not open',409)
      const f=body.feedback||{};const invite=Math.max(0,Math.min(10,Number(f.inviteFriend)));const r=await db.from('event_feedback').upsert({event_id:event.id,user_id:user.id,return_intent:String(f.returnIntent||''),strongest_part:String(f.strongest||'').slice(0,1000),improve_text:String(f.improve||'').slice(0,1000),willingness_to_pay:Number(f.willingness)||null,duration_feel:String(f.durationFeel||''),invite_friend:Number.isFinite(invite)?String(invite):null});if(r.error)throw r.error;return json({ok:true})
    }

    if(!adminTokenOk)await mustAdmin(db,user,tg)

    if(action==='admin-stage'){
      const to=String(body.status||''); if(manualTransitions[event.status]!==to && body.force!==true)return err(`This transition is produced by a dedicated action: ${event.status} -> ${to}`,409)
      const r=await db.from('events').update({status:to}).eq('id',event.id);if(r.error)throw r.error
      await db.from('event_transitions').insert({event_id:event.id,from_status:event.status,to_status:to,actor_user_id:user?.id||null,metadata:{forced:body.force===true}})
      return json({ok:true,status:to})
    }
    if(action==='admin-capacity'){
      const capacity=Math.max(1,Math.min(500,Number(body.capacity)||30));const r=await db.from('events').update({capacity}).eq('id',event.id);if(r.error)throw r.error;return json({ok:true,capacity})
    }
    if(action==='admin-grant-test-ticket'){
      const raw=String(body.username||'').trim().replace(/^@/,'')
      if(!raw)return err('Telegram username required')
      const target=await db.from('users').select('id,telegram_username,display_name').ilike('telegram_username',raw).maybeSingle()
      if(target.error)throw target.error
      if(!target.data)return err('User has not opened the Mini App yet',404)
      const r=await db.from('registrations').upsert({event_id:event.id,user_id:target.data.id,status:'paid',amount_rub:0,payment_provider:'test',paid_at:new Date().toISOString(),reservation_expires_at:null},{onConflict:'event_id,user_id'})
      if(r.error)throw r.error
      return json({ok:true,user:{username:target.data.telegram_username,name:target.data.display_name}})
    }
    if(action==='admin-screen-message'){
      const settings={...(event.settings||{}),screen_message:String(body.message||'').slice(0,180)};const r=await db.from('events').update({settings}).eq('id',event.id);if(r.error)throw r.error;return json({ok:true})
    }
    if(action==='admin-configure-telegram'){
      const webAppUrl=Deno.env.get('TELEGRAM_WEBAPP_URL')||''
      const webhookSecret=Deno.env.get('TELEGRAM_WEBHOOK_SECRET')||''
      if(!webAppUrl)throw new Error('TELEGRAM_WEBAPP_URL missing')
      if(!webhookSecret)throw new Error('TELEGRAM_WEBHOOK_SECRET missing')
      const webhookUrl=`${webAppUrl}${webAppUrl.includes('?')?'&':'?'}mode=telegram`
      const webhook=await telegramBot('setWebhook',{url:webhookUrl,secret_token:webhookSecret,allowed_updates:['message','pre_checkout_query'],drop_pending_updates:false})
      const menu=await telegramBot('setChatMenuButton',{menu_button:{type:'web_app',text:'открыть клуб',web_app:{url:webAppUrl}}})
      await telegramBot('setMyCommands',{commands:[{command:'start',description:'открыть клуб'},{command:'paysupport',description:'вопросы по оплате'}]})
      const me=await telegramBot('getMe',{})
      return json({ok:true,bot:{id:me.id,username:me.username},webhook,menu,webAppUrl})
    }
    if(action==='ai-select-ideas'){
      if(event.status!=='IDEAS_LOCKED')return err('AI idea selection is only available after ideas are locked',409)
      const ideas=await db.from('film_ideas').select('id,title,plot').eq('event_id',event.id);if(ideas.error)throw ideas.error;if((ideas.data||[]).length<3)return err('Need at least 3 ideas',409)
      const schema={type:'object',additionalProperties:false,properties:{selected:{type:'array',minItems:3,maxItems:3,items:{type:'object',additionalProperties:false,properties:{id:{type:'string'},reason:{type:'string'}},required:['id','reason']}}},required:['selected']}
      const out=await structuredResponse<any>({name:'select_ideas',schema,instructions:JIPITINA,input:`Выбери ровно 3 самые интересные, странные или потенциально плодотворные идеи. Не пытайся угадывать авторов. Вот заявки JSON:\n${JSON.stringify(ideas.data)}`})
      const valid=new Set((ideas.data||[]).map((x:any)=>x.id)); if(out.selected.some((x:any)=>!valid.has(x.id)))throw new Error('AI selected unknown idea')
      await db.from('idea_finalists').delete().eq('event_id',event.id)
      const rows=out.selected.map((x:any,i:number)=>({event_id:event.id,film_idea_id:x.id,rank:i+1,ai_reason:x.reason}));const ins=await db.from('idea_finalists').insert(rows);if(ins.error)throw ins.error
      await db.from('events').update({status:'TOP3_READY'}).eq('id',event.id); return json({ok:true,selected:out.selected})
    }
    if(action==='draw-idea'){
      if(event.status!=='TOP3_READY')return err('Idea draw is not available at this stage',409)
      const fs=await db.from('idea_finalists').select('film_idea_id').eq('event_id',event.id).order('rank');if(fs.error)throw fs.error;const list=(fs.data||[]).map((x:any)=>x.film_idea_id);if(list.length!==3)return err('Need 3 finalists',409)
      const {index,randomBytesHex}=secureIndex(list.length);const chosen=list[index]
      await db.from('random_draws').insert({event_id:event.id,draw_type:'idea',candidate_ids:list,chosen_id:chosen,random_bytes_hex:randomBytesHex})
      const idea=await db.from('film_ideas').select('user_id').eq('id',chosen).single();await db.from('selected_idea').upsert({event_id:event.id,film_idea_id:chosen,revealed_author_user_id:idea.data.user_id})
      await db.from('events').update({status:'IDEA_RANDOMIZED'}).eq('id',event.id); return json({ok:true,chosen,randomBytesHex})
    }
    if(action==='ai-find-movies'){
      if(!['IDEA_RANDOMIZED','MOVIE_SEARCH'].includes(event.status))return err('Movie search is not available at this stage',409)
      await db.from('events').update({status:'MOVIE_SEARCH'}).eq('id',event.id)
      const sel=await db.from('selected_idea').select('film_ideas(title,plot)').eq('event_id',event.id).single();if(sel.error)throw sel.error
      const regs=await db.from('registrations').select('user_id').eq('event_id',event.id).in('status',['paid','attended']); const userIds=(regs.data||[]).map((x:any)=>x.user_id); const profiles=userIds.length?await db.from('cinema_profiles').select('user_id,favorite_films,favorite_genres,avoid').in('user_id',userIds):{data:[]} as any
      const schema={type:'object',additionalProperties:false,properties:{candidates:{type:'array',minItems:8,maxItems:12,items:{type:'object',additionalProperties:false,properties:{title:{type:'string'},originalTitle:{type:'string'},year:{type:['integer','null']},similarityScore:{type:'number',minimum:0,maximum:100},audienceFitScore:{type:'number',minimum:0,maximum:100},reason:{type:'string'}},required:['title','originalTitle','year','similarityScore','audienceFitScore','reason']}}},required:['candidates']}
      const out=await structuredResponse<any>({name:'movie_candidates',schema,instructions:JIPITINA,input:`Найди реальные полнометражные фильмы или анимацию со всего мира, близкие одновременно к названию и сюжету придуманного фильма. Главный вес: сходство с идеей 70%, агрегированный вкус группы 30%. Не предлагай то, в существовании чего сомневаешься. Идея: ${JSON.stringify((sel.data as any).film_ideas)}. Профили группы: ${JSON.stringify(profiles.data||[])}`,maxOutputTokens:3000,model:Deno.env.get('OPENAI_FILM_MODEL')||'gpt-5.6-terra'})
      const validated:any[]=[]
      for(const c of out.candidates){
        if(validated.length>=8)break
        const v=await validateMovieTitle(c.originalTitle||c.title,c.year||undefined)
        if(!v?.runtimeMin)continue
        if(v.runtimeMin>event.max_movie_runtime_min)continue
        validated.push({...c,...v,runtimeMin:v.runtimeMin})
      }
      if(validated.length<3)return err('Could not validate 3 movie candidates; admin fallback required',422)
      await db.from('movie_candidates').delete().eq('event_id',event.id)
      const rows=validated.map(c=>({event_id:event.id,provider:'wikidata',provider_id:c.wikidataId,title:c.title,original_title:c.originalTitle||c.title,year:c.year||null,runtime_min:c.runtimeMin||null,validated:true,similarity_score:c.similarityScore,audience_fit_score:c.audienceFitScore,reason:c.reason,metadata:{wikidata_url:c.url,description:c.description}}))
      const ins=await db.from('movie_candidates').insert(rows).select('*');if(ins.error)throw ins.error
      const top=(ins.data||[]).filter((x:any)=>x.runtime_min&&x.runtime_min<=event.max_movie_runtime_min).sort((a:any,b:any)=>Number(b.weighted_score)-Number(a.weighted_score)).slice(0,3)
      if(top.length<3)return err('Need 3 valid finalists',422)
      await db.from('movie_finalists').delete().eq('event_id',event.id);await db.from('movie_finalists').insert(top.map((x:any,i:number)=>({event_id:event.id,movie_candidate_id:x.id,rank:i+1})))
      await db.from('events').update({status:'MOVIE_FINALISTS'}).eq('id',event.id); return json({ok:true,candidates:ins.data,finalists:top})
    }
    if(action==='draw-movie'){
      if(event.status!=='MOVIE_FINALISTS')return err('Movie draw is not available at this stage',409)
      const fs=await db.from('movie_finalists').select('movie_candidate_id').eq('event_id',event.id).order('rank');if(fs.error)throw fs.error;const list=(fs.data||[]).map((x:any)=>x.movie_candidate_id);if(list.length!==3)return err('Need 3 movie finalists',409)
      const {index,randomBytesHex}=secureIndex(3);const chosen=list[index]
      await db.from('random_draws').insert({event_id:event.id,draw_type:'movie',candidate_ids:list,chosen_id:chosen,random_bytes_hex:randomBytesHex});await db.from('event_movie').upsert({event_id:event.id,movie_candidate_id:chosen});await db.from('events').update({status:'MOVIE_SELECTED'}).eq('id',event.id)
      return json({ok:true,chosen,randomBytesHex})
    }
    if(action==='ai-generate-predictions'){
      if(event.status!=='MOVIE_SELECTED')return err('Prediction generation is not available at this stage',409)
      const mv=await db.from('event_movie').select('movie_candidates(title,original_title,year,metadata)').eq('event_id',event.id).single();if(mv.error)throw mv.error
      const schema={type:'object',additionalProperties:false,properties:{questions:{type:'array',minItems:10,maxItems:10,items:{type:'string'}}},required:['questions']}
      const out=await structuredResponse<any>({name:'predictions',schema,instructions:JIPITINA,input:`Для реально существующего фильма создай 10 проверяемых утверждений «будет / не будет». Нельзя использовать имена персонажей, прямые спойлеры, название финального твиста или формулировки, которые раскрывают исход. Утверждения должны быть однозначно проверяемы после просмотра. Фильм: ${JSON.stringify((mv.data as any).movie_candidates)}`})
      await db.from('prediction_questions').delete().eq('event_id',event.id);const ins=await db.from('prediction_questions').insert(out.questions.map((text:string,i:number)=>({event_id:event.id,position:i+1,text}))).select('*');if(ins.error)throw ins.error;await db.from('events').update({status:'PREDICTIONS_OPEN'}).eq('id',event.id);return json({ok:true,questions:ins.data})
    }
    if(action==='ai-post-film-synthesis'){
      if(event.status!=='DISCUSSION')return err('Group synthesis is only available during discussion',409)
      const thoughts=await db.from('discussion_thoughts').select('user_id,text').eq('event_id',event.id)
      if(!(thoughts.data||[]).length)return err('No discussion thoughts yet',409)
      const memories=await db.from('jipitina_memory').select('memory_key,memory_text').eq('scope','club').limit(30)
      const schema={type:'object',additionalProperties:false,properties:{consensus:{type:'string'},disagreements:{type:'string'},jipitinaTake:{type:'string'},questionsForRoom:{type:'array',minItems:1,maxItems:3,items:{type:'string'}}},required:['consensus','disagreements','jipitinaTake','questionsForRoom']}
      const out=await structuredResponse<any>({name:'post_film_synthesis',schema,instructions:JIPITINA+`\nПамять клуба: ${JSON.stringify(memories.data||[])}`,input:`Вот короткие мысли участников после фильма. Не делай вид, что существует консенсус, если его нет. Найди реальное совпадение, реальное расхождение и сформулируй собственную позицию, с которой можно спорить. Мысли: ${JSON.stringify(thoughts.data)}`})
      await db.from('event_outputs').upsert({event_id:event.id,output_key:'post_film_synthesis',payload:out,approved:false,updated_at:new Date().toISOString()})
      return json({ok:true,output:out})
    }
    if(action==='ai-collective-review'){
      if(event.status!=='FINAL_REVIEW')return err('Collective review is only available at the final review stage',409)
      const reviews=await db.from('final_reviews').select('rating,final_sentence').eq('event_id',event.id)
      if(!(reviews.data||[]).length)return err('No final reviews yet',409)
      const movie=await db.from('event_movie').select('movie_candidates(title,year)').eq('event_id',event.id).single()
      const avg=(reviews.data||[]).reduce((a:number,x:any)=>a+Number(x.rating),0)/(reviews.data||[]).length
      const schema={type:'object',additionalProperties:false,properties:{intro:{type:'string'},caption:{type:'string'}},required:['intro','caption']}
      const ai=await structuredResponse<any>({name:'collective_review',schema,instructions:JIPITINA,input:`Напиши очень короткое вступление и подпись к коллективной рецензии клуба. Не переписывай фразы людей — они будут добавлены системой дословно. Фильм: ${JSON.stringify(movie.data)}. Средняя оценка: ${avg.toFixed(1)}. Анонимные финальные фразы для понимания тона: ${JSON.stringify((reviews.data||[]).map((x:any)=>x.final_sentence))}`})
      const out={...ai,averageRating:Number(avg.toFixed(1)),sentences:(reviews.data||[]).map((x:any)=>x.final_sentence)}
      await db.from('event_outputs').upsert({event_id:event.id,output_key:'collective_review',payload:out,approved:false,updated_at:new Date().toISOString()})
      return json({ok:true,output:out})
    }
    if(action==='ai-finalize-memory'){
      if(event.status!=='CLOSED')return err('Club memory can only be finalized after the event is closed',409)
      const [feedback,reviews,outputs]=await Promise.all([db.from('event_feedback').select('return_intent,strongest_part,improve_text,willingness_to_pay').eq('event_id',event.id),db.from('final_reviews').select('rating,final_sentence').eq('event_id',event.id),db.from('event_outputs').select('output_key,payload').eq('event_id',event.id)])
      const schema={type:'object',additionalProperties:false,properties:{memories:{type:'array',minItems:1,maxItems:8,items:{type:'object',additionalProperties:false,properties:{key:{type:'string'},text:{type:'string'}},required:['key','text']}}},required:['memories']}
      const out=await structuredResponse<any>({name:'club_memory',schema,instructions:JIPITINA,input:`Сохрани только устойчивые факты, которые полезны на будущих вечерах: вкусы группы, уже возникшие традиции/шутки, важные уроки формата. Не сохраняй чувствительные персональные данные и не делай психологических выводов о людях. Feedback: ${JSON.stringify(feedback.data||[])} Reviews: ${JSON.stringify(reviews.data||[])} Event outputs: ${JSON.stringify(outputs.data||[])}`})
      for(const m of out.memories){await db.from('jipitina_memory').upsert({scope:'club',scope_id:'00000000-0000-0000-0000-000000000000',memory_key:`event_${event.id}_${String(m.key).slice(0,80)}`,memory_text:String(m.text).slice(0,800),source:`event:${event.id}`},{onConflict:'scope,scope_id,memory_key'})}
      await db.from('event_outputs').upsert({event_id:event.id,output_key:'memory_saved',payload:{count:out.memories.length,memories:out.memories},approved:true,updated_at:new Date().toISOString()})
      return json({ok:true,memories:out.memories})
    }
    if(action==='admin-research-summary'){
      if(!['FEEDBACK','CLOSED'].includes(event.status))return err('Research summary is only available during or after feedback',409)
      const r=await db.from('event_feedback').select('return_intent,strongest_part,improve_text,willingness_to_pay,duration_feel,invite_friend').eq('event_id',event.id)
      if(r.error)throw r.error
      const rows=r.data||[]
      if(!rows.length)return err('No feedback responses yet',409)
      const returnPositive=rows.filter((x:any)=>['да','скорее да'].includes(String(x.return_intent).toLowerCase())).length
      const wtps=rows.map((x:any)=>Number(x.willingness_to_pay)).filter((x:number)=>Number.isFinite(x)&&x>0)
      const invite=rows.map((x:any)=>Number(x.invite_friend)).filter((x:number)=>Number.isFinite(x)&&x>=0&&x<=10)
      const promoters=invite.filter((x:number)=>x>=9).length,detractors=invite.filter((x:number)=>x<=6).length
      const duration=Object.fromEntries(['коротко','нормально','долго'].map(k=>[k,rows.filter((x:any)=>String(x.duration_feel)===k).length]))
      const payload={responses:rows.length,returnIntentPositivePct:Number((returnPositive/rows.length*100).toFixed(1)),averageWillingnessRub:wtps.length?Math.round(wtps.reduce((a:number,b:number)=>a+b,0)/wtps.length):null,nps:invite.length?Math.round((promoters-detractors)/invite.length*100):null,duration,strongest:rows.map((x:any)=>x.strongest_part).filter(Boolean),improvements:rows.map((x:any)=>x.improve_text).filter(Boolean)}
      await db.from('event_outputs').upsert({event_id:event.id,output_key:'research_summary',payload,approved:true,updated_at:new Date().toISOString()})
      return json({ok:true,output:payload})
    }
    if(action==='admin-score-predictions'){
      if(!['PREDICTIONS_LOCKED','WATCHING'].includes(event.status))return err('Prediction scoring is not available at this stage',409)
      const actuals=body.actuals||{}
      const qs=await db.from('prediction_questions').select('id').eq('event_id',event.id);if(qs.error)throw qs.error
      for(const q of qs.data||[]){if(typeof actuals[q.id]==='boolean')await db.from('prediction_questions').update({actual:actuals[q.id]}).eq('id',q.id)}
      const answers=await db.from('prediction_answers').select('user_id,question_id,answer').eq('event_id',event.id)
      const updated=await db.from('prediction_questions').select('id,actual,void').eq('event_id',event.id)
      const map=new Map((updated.data||[]).map((q:any)=>[q.id,q]))
      const scores=new Map<string,{correct:number,total:number}>()
      for(const a of answers.data||[]){
        const q:any=map.get(a.question_id);if(!q||q.void||typeof q.actual!=='boolean')continue
        const score=scores.get(a.user_id)||{correct:0,total:0};score.total++;if(a.answer===q.actual)score.correct++;scores.set(a.user_id,score)
      }
      const sorted=[...scores.entries()].map(([uid,score])=>({event_id:event.id,user_id:uid,correct:score.correct,total:score.total,points:score.correct})).sort((a,b)=>b.correct-a.correct)
      let previousCorrect:number|undefined, previousRank=0
      const rows=sorted.map((x,i)=>{if(previousCorrect===undefined||x.correct!==previousCorrect){previousCorrect=x.correct;previousRank=i+1}return {...x,rank:previousRank}})
      if(rows.length){const up=await db.from('event_scores').upsert(rows);if(up.error)throw up.error}
      const named=await db.from('event_scores').select('user_id,correct,total,points,rank,users(display_name,telegram_username)').eq('event_id',event.id).order('rank').order('correct',{ascending:false})
      if(named.error)throw named.error
      const publicScores=(named.data||[]).map((x:any)=>({userId:x.user_id,name:x.users?.display_name||x.users?.telegram_username||'участник',correct:x.correct,total:x.total,points:x.points,rank:x.rank}))
      const winners=publicScores.filter((x:any)=>x.rank===1)
      const soleWinner=winners.length===1?winners[0]:null
      await db.from('events').update({status:'PREDICTIONS_SCORED',winner_user_id:soleWinner?.userId||null}).eq('id',event.id)
      await db.from('event_outputs').upsert({event_id:event.id,output_key:'score_summary',payload:{scores:publicScores,tie:winners.length>1,winners,winner:soleWinner},approved:true,updated_at:new Date().toISOString()})
      await refreshLeaderboard(db,rows.map(x=>x.user_id))
      return json({ok:true,scores:publicScores,tie:winners.length>1,winners,winner:soleWinner})
    }
    if(action==='ai-tiebreaker'){
      if(event.status!=='PREDICTIONS_SCORED')return err('Tie-breaker is only available after scoring',409)
      const score=await db.from('event_outputs').select('payload').eq('event_id',event.id).eq('output_key','score_summary').maybeSingle()
      const winners=(score.data?.payload as any)?.winners||[]
      if(winners.length<2)return err('There is no tie for first place',409)
      const schema={type:'object',additionalProperties:false,properties:{clue:{type:'string'}},required:['clue']}
      const out=await structuredResponse<any>({name:'tiebreaker',schema,instructions:JIPITINA,input:'Выбери широко известный фильм, который с высокой вероятностью знают люди 20–35 лет, и максимально убого перескажи его в 2–4 коротких предложениях. Нельзя писать название, имена персонажей, актёров, режиссёра, франшизу или уникальные собственные имена. Пересказ должен быть смешным, узнаваемым, но не мгновенно очевидным.'})
      await db.from('event_outputs').upsert({event_id:event.id,output_key:'tiebreaker',payload:{...out,generatedAt:new Date().toISOString()},approved:true,updated_at:new Date().toISOString()})
      return json({ok:true,output:out})
    }
    if(action==='admin-set-winner'){
      if(event.status!=='PREDICTIONS_SCORED')return err('Winner can only be resolved after scoring',409)
      const chosen=String(body.userId||'')
      const top=await db.from('event_scores').select('user_id').eq('event_id',event.id).eq('rank',1)
      if(top.error)throw top.error
      const allowed=(top.data||[]).map((x:any)=>x.user_id)
      if(!allowed.includes(chosen))return err('Chosen user is not tied for first place',409)
      const u=await db.from('users').select('display_name,telegram_username').eq('id',chosen).single();if(u.error)throw u.error
      await db.from('events').update({winner_user_id:chosen}).eq('id',event.id)
      const score=await db.from('event_outputs').select('payload').eq('event_id',event.id).eq('output_key','score_summary').single();if(score.error)throw score.error
      const winner={userId:chosen,name:u.data.display_name||u.data.telegram_username||'участник'}
      await db.from('event_outputs').upsert({event_id:event.id,output_key:'score_summary',payload:{...(score.data.payload as any),tie:false,tieResolved:true,winner},approved:true,updated_at:new Date().toISOString()})
      await refreshLeaderboard(db,allowed)
      return json({ok:true,winner})
    }
    return err(`Unknown action: ${action}`,404)
  }catch(e){console.error(e);return err(e instanceof Error?e.message:'Unknown error',500)}
}

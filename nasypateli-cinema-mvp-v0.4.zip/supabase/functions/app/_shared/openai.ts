const endpoint='https://api.openai.com/v1/responses'

export async function structuredResponse<T>(args:{name:string;schema:Record<string,unknown>;instructions:string;input:string;maxOutputTokens?:number;model?:string}):Promise<T>{
  const key=Deno.env.get('OPENAI_API_KEY')
  if(!key) throw new Error('OPENAI_API_KEY is missing')
  const model=args.model||Deno.env.get('OPENAI_MODEL')||'gpt-5.6-luna'
  const body={
    model,
    instructions:args.instructions,
    input:args.input,
    max_output_tokens:args.maxOutputTokens||1800,
    text:{format:{type:'json_schema',name:args.name,strict:true,schema:args.schema}}
  }
  const r=await fetch(endpoint,{method:'POST',headers:{authorization:`Bearer ${key}`,'content-type':'application/json'},body:JSON.stringify(body)})
  const json=await r.json()
  if(!r.ok) throw new Error(json?.error?.message||`OpenAI ${r.status}`)
  const text=json.output_text || json.output?.flatMap((x:any)=>x.content||[]).find((x:any)=>x.type==='output_text')?.text
  if(!text) throw new Error('OpenAI returned no output_text')
  return JSON.parse(text) as T
}

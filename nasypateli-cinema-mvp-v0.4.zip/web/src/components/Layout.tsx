import { NavLink, Outlet } from 'react-router-dom'
import { demoMode } from '../lib/api'

export default function Layout(){
  return <div className="app-shell">
    <header className="topbar">
      <NavLink className="brand" to="/">насыпатели <span>в кино</span></NavLink>
      <div className="topbar-actions">{demoMode && <span className="demo-badge">demo</span>}<NavLink className="jipitina-top" to="/jipitina" aria-label="открыть Джипитину">дж</NavLink></div>
    </header>
    <main><Outlet/></main>
    <nav className="bottom-nav">
      <NavLink to="/">событие</NavLink>
      <NavLink to="/profile">профиль</NavLink>
      <NavLink to="/club">клуб</NavLink>
    </nav>
  </div>
}

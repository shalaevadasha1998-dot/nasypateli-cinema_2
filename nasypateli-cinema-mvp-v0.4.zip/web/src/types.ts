export type EventStatus =
  | 'DRAFT'|'SALES_OPEN'|'CHECKIN'|'IDEAS_OPEN'|'IDEAS_LOCKED'|'TOP3_READY'|'IDEA_RANDOMIZED'
  | 'MOVIE_SEARCH'|'MOVIE_FINALISTS'|'MOVIE_SELECTED'|'PREDICTIONS_OPEN'|'PREDICTIONS_LOCKED'
  | 'WATCHING'|'PREDICTIONS_SCORED'|'DISCUSSION'|'FINAL_REVIEW'|'FEEDBACK'|'CLOSED'

export type EventInfo = {
  id: string
  slug: string
  title: string
  startsAt: string
  capacity: number
  sold: number
  ticketPriceRub: number
  maxMovieRuntimeMin: number
  status: EventStatus
  venueName?: string
  venueAddress?: string
}

export type CinemaProfile = {
  displayName: string
  favoriteFilms: string
  favoriteGenres: string
  avoid: string
  photoVideoConsent: boolean
}

export type FilmIdea = { id:string; title:string; plot:string; author?:string }
export type MovieCandidate = { id:string; title:string; year?:number; runtimeMin?:number; reason?:string; score?:number }
export type Prediction = { id:string; position:number; text:string; answer?:boolean; actual?:boolean }
export type LeaderRow = { name:string; points:number; wins:number; events:number }

export type DemoState = {
  event: EventInfo
  profile: CinemaProfile
  registration: 'none'|'reserved'|'paid'|'waitlist'|'refunded'
  idea?: FilmIdea
  ideaFinalists: FilmIdea[]
  selectedIdea?: FilmIdea
  movieFinalists: MovieCandidate[]
  selectedMovie?: MovieCandidate
  predictions: Prediction[]
  predictionSubmitted: boolean
  thought?: string
  review?: {rating:number; sentence:string}
  feedback?: {returnIntent:string; strongest:string; improve:string; willingness:number; durationFeel?:string; inviteFriend?:number}
  leaderboard: LeaderRow[]
  screenMessage?: string
  outputs?: Record<string, unknown>
}

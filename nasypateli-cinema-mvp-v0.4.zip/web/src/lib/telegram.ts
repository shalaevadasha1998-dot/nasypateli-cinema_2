declare global {
  interface Window {
    Telegram?: {
      WebApp?: {
        initData?: string
        initDataUnsafe?: { user?: { id:number; first_name?:string; last_name?:string; username?:string } }
        ready?: () => void
        expand?: () => void
        close?: () => void
        openInvoice?: (url:string, cb?:(status:string)=>void) => void
        themeParams?: Record<string,string>
      }
    }
  }
}

export function telegramWebApp() {
  return window.Telegram?.WebApp
}

export function initTelegram() {
  const app = telegramWebApp()
  app?.ready?.()
  app?.expand?.()
  return app
}

export function telegramInitData() {
  return telegramWebApp()?.initData || ''
}

export function telegramUser() {
  return telegramWebApp()?.initDataUnsafe?.user
}

declare global {
  interface Window {
    Telegram?: {
      WebApp?: {
        initData?: string
        initDataUnsafe?: {
          user?: { id:number; first_name?:string; last_name?:string; username?:string; photo_url?:string; language_code?:string }
          start_param?:string
        }
        ready?: () => void
        expand?: () => void
        close?: () => void
        openInvoice?: (url:string, cb?:(status:string)=>void) => void
        themeParams?: Record<string,string>
        disableVerticalSwipes?:()=>void
      }
    }
  }
}

export function telegramWebApp() { return window.Telegram?.WebApp }
export function initTelegram() {
  const app = telegramWebApp()
  app?.ready?.()
  app?.expand?.()
  app?.disableVerticalSwipes?.()
  return app
}
export function telegramInitData() { return telegramWebApp()?.initData || '' }
export function telegramUser() { return telegramWebApp()?.initDataUnsafe?.user }
export function telegramStartParam(){ return telegramWebApp()?.initDataUnsafe?.start_param || '' }

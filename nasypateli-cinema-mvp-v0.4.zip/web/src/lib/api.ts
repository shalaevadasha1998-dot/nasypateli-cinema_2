import type { CinemaProfile, DemoState, EventStatus, JipitinaMessage, PostFilmReaction } from '../types'
import { applyStageData, initialDemoState, loadDemo, saveDemo } from '../demo'
import { telegramInitData, telegramWebApp } from './telegram'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined
const fn = (import.meta.env.VITE_API_FUNCTION as string | undefined) || 'app'
export const demoMode = import.meta.env.VITE_DEMO_MODE !== 'false' || !supabaseUrl

function notifyDemo(){ window.dispatchEvent(new CustomEvent('nasypateli-demo-change')) }

export async function callApi<T=unknown>(action:string,payload:Record<string,unknown>={}):Promise<T>{
  if(demoMode) return demoAction(action,payload) as T
  const res=await fetch(`${supabaseUrl}/functions/v1/${fn}`,{
    method:'POST',
    headers:{'content-type':'application/json','x-telegram-init-data':telegramInitData()},
    body:JSON.stringify({action,...payload})
  })
  const data=await res.json().catch(()=>({error:'invalid response'}))
  if(!res.ok) throw new Error(data.error || `API ${res.status}`)
  return data as T
}

function mutate(mutator:(s:DemoState)=>DemoState){
  const next=mutator(loadDemo()); saveDemo(next); notifyDemo(); return next
}

function demoReply(message:string,mode:string):string{
  const m=message.toLowerCase()
  if(mode==='idea_coach'){
    if(m.includes('нет идеи')||m.includes('придум')) return 'давай не начинать с сюжета. выбери одну штуку, которая в обычном мире невозможна, но в фильме считается нормой. например: у людей исчезают имена после полуночи. что тебе ближе — правило мира, странное место или странный человек?'
    return 'в черновике уже есть ядро. я бы пока не добавляла событий, а уточнила одно правило: что здесь невозможно отменить или избежать? это даст идее собственную логику.'
  }
  if(mode==='post_film') return 'ты ожидала более жанровую историю, а оценка всё равно высокая. что сработало сильнее ожиданий: атмосфера, устройство мира или люди внутри него?'
  return 'я здесь. могу разобрать твой вкус, помочь придумать идею для вечера или поговорить про то, что мы уже смотрели.'
}

function demoAction(action:string,payload:Record<string,unknown>){
  switch(action){
    case 'bootstrap': return loadDemo()
    case 'save-profile-progress': return mutate(s=>({...s,profile:{...s.profile,...(payload.profile as Partial<CinemaProfile>),onboardingStep:Number(payload.step)||s.profile.onboardingStep}}))
    case 'save-profile': return mutate(s=>({...s,profile:{...(payload.profile as CinemaProfile),completed:true,completedAt:new Date().toISOString()},onboardingComplete:true}))
    case 'reserve-ticket': return mutate(s=>({...s,registration:s.event.sold>=s.event.capacity?'waitlist':'paid',event:{...s.event,sold:s.event.sold+(s.event.sold<s.event.capacity?1:0)}}))
    case 'submit-idea': return mutate(s=>({...s,idea:{id:'mine',title:String(payload.title||''),plot:String(payload.plot||'')}}))
    case 'submit-predictions': return mutate(s=>({...s,predictions:(payload.predictions as DemoState['predictions'])||s.predictions,predictionSubmitted:true}))
    case 'submit-reaction': return mutate(s=>({...s,reaction:payload.reaction as PostFilmReaction,thought:(payload.reaction as PostFilmReaction)?.thought}))
    case 'submit-thought': return mutate(s=>({...s,thought:String(payload.text||'')}))
    case 'submit-review': return mutate(s=>({...s,review:{rating:Number(payload.rating),sentence:String(payload.sentence||'')}}))
    case 'submit-feedback': return mutate(s=>({...s,feedback:payload.feedback as DemoState['feedback']}))
    case 'jipitina-chat': return mutate(s=>{
      const text=String(payload.message||'');const mode=String(payload.mode||'general');const now=new Date().toISOString();
      const userMsg:JipitinaMessage={id:`u-${Date.now()}`,role:'user',text,mode,createdAt:now}
      const assistant:JipitinaMessage={id:`a-${Date.now()}`,role:'assistant',text:demoReply(text,mode),mode,createdAt:new Date().toISOString()}
      return {...s,jipitinaMessages:[...(s.jipitinaMessages||[]),userMsg,assistant].slice(-30)}
    })
    case 'admin-stage': return mutate(s=>applyStageData(s,payload.status as EventStatus))
    case 'admin-set-mechanic': return mutate(s=>({...s,event:{...s.event,nonexistentFilmEnabled:!!payload.enabled}}))
    case 'admin-capacity': return mutate(s=>({...s,event:{...s.event,capacity:Number(payload.capacity)||30}}))
    case 'admin-screen-message': return mutate(s=>({...s,screenMessage:String(payload.message||'')}))
    case 'admin-reveal-idea-author': return mutate(s=>({...s,selectedIdea:s.selectedIdea?{...s.selectedIdea,author:'@demo_author'}:s.selectedIdea}))
    case 'ai-post-film-synthesis': return mutate(s=>({...s,outputs:{...(s.outputs||{}),post_film_synthesis:{consensus:'все увидели фильм по-разному, но почти все зацепились за ощущение ловушки',disagreements:'часть группы считает героя пассивным, часть — единственным рациональным человеком',jipitinaTake:'мне кажется, вы спорите не о герое, а о том, насколько сами готовы принять абсурдные правила мира'}}}))
    case 'ai-collective-review': return mutate(s=>({...s,outputs:{...(s.outputs||{}),collective_review:{intro:'первый фильм клуба оказался одновременно смешнее и тревожнее, чем мы прогнозировали',averageRating:7.6,sentences:[s.review?.sentence||'демо-фраза участника']}}}))
    case 'ai-finalize-memory': return mutate(s=>({...s,outputs:{...(s.outputs||{}),memory_saved:{ok:true}}}))
    case 'admin-research-summary': return mutate(s=>({...s,outputs:{...(s.outputs||{}),research_summary:{responses:24,returnIntentPositivePct:79.2,averageWillingnessRub:1038,nps:42,duration:{коротко:1,нормально:19,долго:4},strongest:['рандом и ощущение, что никто не знает фильм'],improvements:['быстрее начать просмотр']}}}))
    case 'admin-score-predictions': return mutate(s=>({...s,event:{...s.event,status:'PREDICTIONS_SCORED'},outputs:{...(s.outputs||{}),score_summary:{tie:true,winners:[{userId:'demo-1',name:'аня',correct:8,total:10,points:8,rank:1},{userId:'demo-2',name:'ваня',correct:8,total:10,points:8,rank:1}],scores:[{userId:'demo-1',name:'аня',correct:8,total:10,points:8,rank:1},{userId:'demo-2',name:'ваня',correct:8,total:10,points:8,rank:1},{userId:'demo-3',name:'саша',correct:6,total:10,points:6,rank:3}]}}}))
    case 'ai-tiebreaker': return mutate(s=>({...s,outputs:{...(s.outputs||{}),tiebreaker:{clue:'мужик очень долго пытается вернуть украшение владельцу, но все вокруг почему-то считают, что проще было бы его выбросить в вулкан'}}}))
    case 'admin-set-winner': return mutate(s=>{const score:any=s.outputs?.score_summary||{};const winner=(score.winners||[]).find((x:any)=>x.userId===payload.userId)||{userId:String(payload.userId||''),name:'победитель'};return {...s,outputs:{...(s.outputs||{}),score_summary:{...score,tie:false,tieResolved:true,winner}}}})
    case 'reset-demo': localStorage.clear(); notifyDemo(); return structuredClone(initialDemoState)
    default: throw new Error(`Unknown demo action: ${action}`)
  }
}

export async function buyTicket(slug:string){
  if(demoMode) return callApi('reserve-ticket',{slug})
  const res=await fetch(`${supabaseUrl}/functions/v1/${fn}?mode=invoice`,{
    method:'POST',headers:{'content-type':'application/json','x-telegram-init-data':telegramInitData()},body:JSON.stringify({slug})
  })
  const data=await res.json()
  if(res.status===409 && data.waitlist) return data
  if(!res.ok) throw new Error(data.error||`Payment API ${res.status}`)
  if(data.invoiceUrl){
    const app=telegramWebApp()
    if(app?.openInvoice) app.openInvoice(data.invoiceUrl)
    else location.href=data.invoiceUrl
  }
  return data
}

import { useEffect, useMemo, useState } from 'react'
import { BrowserRouter, Route, Routes, useNavigate, useParams } from 'react-router-dom'
import Layout from './components/Layout'
import { Button, Card, Empty, Field, Pill } from './components/UI'
import { buyTicket, callApi, demoMode } from './lib/api'
import { initTelegram, telegramUser } from './lib/telegram'
import { stages } from './demo'
import type { CinemaProfile, DemoState, EventStatus, Prediction } from './types'
import './styles.css'

function useStateData(){
  const [data,setData]=useState<DemoState|null>(null)
  const [error,setError]=useState('')
  const reload=()=>callApi<DemoState>('bootstrap').then(setData).catch(e=>setError(e.message))
  useEffect(()=>{ initTelegram(); reload(); const h=()=>reload(); window.addEventListener('nasypateli-demo-change',h); window.addEventListener('storage',h); const timer=demoMode?undefined:window.setInterval(reload,5000); return()=>{window.removeEventListener('nasypateli-demo-change',h);window.removeEventListener('storage',h);if(timer)window.clearInterval(timer)} },[])
  return {data,setData,error,reload}
}

function Loading({error}:{error?:string}){ return <div className="page"><Card>{error?<>ошибка: {error}</>:<>загрузка…</>}</Card></div> }

function Home(){
  const {data,error,reload}=useStateData(); const nav=useNavigate(); if(!data)return <Loading error={error}/>
  const e=data.event; const left=Math.max(0,e.capacity-e.sold)
  const buy=async()=>{ const r:any=await buyTicket(e.slug); if(r?.waitlist) await reload(); else if(demoMode) await reload() }
  return <div className="page">
    <div className="hero">
      <div className="eyebrow">первый тестовый вечер</div>
      <h1>никто не знает,<br/>что мы посмотрим</h1>
      <p>вы придумываете фильм, которого не существует. джипитина ищет ему реального двойника. рандом решает остальное</p>
    </div>
    <Card>
      <div className="row spread"><strong>3 октября · москва</strong><Pill>{e.ticketPriceRub} ₽</Pill></div>
      <div className="meter"><i style={{width:`${Math.min(100,e.sold/e.capacity*100)}%`}}/></div>
      <div className="muted">{e.sold} из {e.capacity} мест · осталось {left}</div>
      {data.registration==='none' ? <Button onClick={buy}>{left?'купить билет':'встать в лист ожидания'}</Button> : <div className="success">{data.registration==='paid'?'билет ваш. вы внутри':data.registration==='reserved'?'место зарезервировано на 15 минут. завершаем оплату':'вы в листе ожидания'}</div>}
      <Button kind="secondary" onClick={()=>nav(`/event/${e.slug}`)}>открыть механику вечера</Button>
    </Card>
    <Card><div className="section-title">как это работает</div><ol className="steps"><li>придумываете несуществующий фильм</li><li>джипитина выбирает три идеи</li><li>рандом выбирает одну</li><li>она ищет реальный фильм-двойник</li><li>вы делаете 10 прогнозов</li><li>смотрите, спорите и пишете общую рецензию</li></ol></Card>
    {demoMode&&<Card className="dev"><b>демо работает без ключей</b><span>админка: <a href={`/admin/${e.slug}`}>/admin/{e.slug}</a> · экран: <a href={`/screen/${e.slug}`}>/screen/{e.slug}</a></span></Card>}
  </div>
}

function Profile(){
  const {data,error,reload}=useStateData(); const [form,setForm]=useState<CinemaProfile|null>(null)
  useEffect(()=>{if(data&&!form){const tg=telegramUser();setForm({...data.profile,displayName:data.profile.displayName||tg?.first_name||''})}},[data,form])
  if(!data||!form)return <Loading error={error}/>
  const upd=(k:keyof CinemaProfile,v:string|boolean)=>setForm({...form,[k]:v})
  const save=async()=>{await callApi('save-profile',{profile:form});await reload()}
  return <div className="page"><h2>ваш кинопрофиль</h2><p className="muted">джипитина использует его как 30% веса при подборе фильма вечера</p><Card>
    <Field label="как вас называть"><input value={form.displayName} onChange={e=>upd('displayName',e.target.value)} /></Field>
    <Field label="любимые фильмы" hint="через запятую"><textarea value={form.favoriteFilms} onChange={e=>upd('favoriteFilms',e.target.value)} /></Field>
    <Field label="любимые жанры"><input value={form.favoriteGenres} onChange={e=>upd('favoriteGenres',e.target.value)} /></Field>
    <Field label="что совсем не хочется смотреть"><textarea value={form.avoid} onChange={e=>upd('avoid',e.target.value)} /></Field>
    <label className="check"><input type="checkbox" checked={form.photoVideoConsent} onChange={e=>upd('photoVideoConsent',e.target.checked)}/><span>можно снимать меня и использовать фото/видео с мероприятия</span></label>
    <Button onClick={save}>сохранить профиль</Button>
  </Card></div>
}

function EventPage(){
  const {data,error,reload}=useStateData(); const {slug}=useParams(); const [title,setTitle]=useState(''); const [plot,setPlot]=useState('');
  if(!data)return <Loading error={error}/>
  if(slug!==data.event.slug)return <div className="page"><Empty>такого события нет</Empty></div>
  const s=data.event.status
  const submitIdea=async()=>{await callApi('submit-idea',{title,plot});await reload()}
  return <div className="page"><div className="row spread"><h2>3 октября</h2><Pill>{statusLabel(s)}</Pill></div>
    {['SALES_OPEN','CHECKIN'].includes(s)&&<Card><div className="big-copy">пока собираемся</div><p>заполните кинопрофиль. заявка на несуществующий фильм откроется прямо перед началом</p></Card>}
    {s==='IDEAS_OPEN'&&<Card><div className="section-title">придумайте фильм, которого не существует</div><Field label="название · до 5–7 слов"><input maxLength={100} value={title} onChange={e=>setTitle(e.target.value)}/></Field><Field label="сюжет · до 500 знаков"><textarea maxLength={500} value={plot} onChange={e=>setPlot(e.target.value)}/></Field><Button disabled={!title.trim()||!plot.trim()} onClick={submitIdea}>отправить анонимно</Button>{data.idea&&<div className="success">заявка принята. автора пока не видит никто</div>}</Card>}
    {['IDEAS_LOCKED','TOP3_READY'].includes(s)&&<Finalists title="три идеи джипитины" items={data.ideaFinalists.map(x=>({name:x.title,sub:x.plot}))}/>} 
    {['IDEA_RANDOMIZED','MOVIE_SEARCH'].includes(s)&&<Card><div className="eyebrow">выбрано рандомом</div><h3>{data.selectedIdea?.title}</h3><p>{data.selectedIdea?.plot}</p>{data.selectedIdea?.author&&<p className="muted">автор: {data.selectedIdea.author}</p>}<div className="scan">джипитина ищет реального двойника…</div></Card>}
    {s==='MOVIE_FINALISTS'&&<Finalists title="три реальных двойника" items={data.movieFinalists.map(x=>({name:`${x.title}${x.year?` · ${x.year}`:''}`,sub:`${x.runtimeMin||'?'} мин · ${x.reason||''}`}))}/>} 
    {s==='MOVIE_SELECTED'&&<Card><div className="eyebrow">фильм вечера</div><h3>{data.selectedMovie?.title}</h3><p>{data.selectedMovie?.year} · {data.selectedMovie?.runtimeMin} минут</p><p>{data.selectedMovie?.reason}</p></Card>}
    {s==='PREDICTIONS_OPEN'&&<PredictionForm data={data} reload={reload}/>} 
    {['PREDICTIONS_LOCKED','WATCHING'].includes(s)&&<Card><div className="big-copy">телефоны вниз</div><p>{data.predictionSubmitted?'ваши прогнозы зафиксированы.':'прогнозы закрыты.'} смотрим фильм целиком</p></Card>}
    {s==='PREDICTIONS_SCORED'&&<Card><div className="big-copy">прогнозы посчитаны</div><p>таблица результатов появляется на общем экране</p></Card>}
    {s==='DISCUSSION'&&<ThoughtForm data={data} reload={reload}/>} 
    {s==='FINAL_REVIEW'&&<ReviewForm data={data} reload={reload}/>} 
    {s==='FEEDBACK'&&<FeedbackForm data={data} reload={reload}/>} 
    {s==='CLOSED'&&<Card><div className="big-copy">вечер закрыт</div><p>завтра здесь появится коллективная рецензия. спасибо, что были внутри эксперимента</p></Card>}
  </div>
}

function PredictionForm({data,reload}:{data:DemoState;reload:()=>void}){
  const [answers,setAnswers]=useState<Record<string,boolean>>(()=>Object.fromEntries(data.predictions.filter(p=>p.answer!==undefined).map(p=>[p.id,p.answer!])))
  const done=Object.keys(answers).length===data.predictions.length
  const submit=async()=>{const predictions=data.predictions.map(p=>({...p,answer:answers[p.id]}));await callApi('submit-predictions',{predictions});await reload()}
  return <Card><div className="section-title">10 прогнозов</div><p className="muted">решите, будет это в фильме или нет. после старта изменить ответы нельзя</p>{data.predictions.map(p=><div className="prediction" key={p.id}><b>{p.position}. {p.text}</b><div className="binary"><button className={answers[p.id]===true?'active':''} onClick={()=>setAnswers({...answers,[p.id]:true})}>будет</button><button className={answers[p.id]===false?'active':''} onClick={()=>setAnswers({...answers,[p.id]:false})}>не будет</button></div></div>)}<Button disabled={!done||data.predictionSubmitted} onClick={submit}>{data.predictionSubmitted?'ответы зафиксированы':'зафиксировать прогнозы'}</Button></Card>
}

function ThoughtForm({data,reload}:{data:DemoState;reload:()=>void}){const [text,setText]=useState(data.thought||'');return <Card><div className="section-title">одна мысль джипитине</div><p className="muted">коротко. что здесь было главным лично для вас?</p><textarea maxLength={240} value={text} onChange={e=>setText(e.target.value)}/><div className="counter">{text.length}/240</div><Button disabled={!text.trim()} onClick={async()=>{await callApi('submit-thought',{text});await reload()}}>отправить</Button></Card>}

function ReviewForm({data,reload}:{data:DemoState;reload:()=>void}){const [rating,setRating]=useState(data.review?.rating||7);const [sentence,setSentence]=useState(data.review?.sentence||'');return <Card><div className="section-title">ваша строка в общей рецензии</div><div className="rating">{[1,2,3,4,5,6,7,8,9,10].map(n=><button className={rating===n?'active':''} key={n} onClick={()=>setRating(n)}>{n}</button>)}</div><Field label="ровно одна финальная фраза"><textarea maxLength={180} value={sentence} onChange={e=>setSentence(e.target.value)}/></Field><Button disabled={!sentence.trim()} onClick={async()=>{await callApi('submit-review',{rating,sentence});await reload()}}>сохранить без редактуры</Button></Card>}

function FeedbackForm({data,reload}:{data:DemoState;reload:()=>void}){const [returnIntent,setReturn]=useState(data.feedback?.returnIntent||'да');const [strongest,setStrongest]=useState(data.feedback?.strongest||'');const [improve,setImprove]=useState(data.feedback?.improve||'');const [willingness,setWtp]=useState(data.feedback?.willingness||900);const [durationFeel,setDuration]=useState(data.feedback?.durationFeel||'нормально');const [inviteFriend,setInvite]=useState(data.feedback?.inviteFriend??8);return <Card><div className="section-title">3 минуты на исследование</div><Field label="придёте ещё?"><select value={returnIntent} onChange={e=>setReturn(e.target.value)}><option>да</option><option>скорее да</option><option>не знаю</option><option>скорее нет</option><option>нет</option></select></Field><Field label="что было самым сильным?"><textarea value={strongest} onChange={e=>setStrongest(e.target.value)}/></Field><Field label="что надо исправить?"><textarea value={improve} onChange={e=>setImprove(e.target.value)}/></Field><Field label="по длительности"><select value={durationFeel} onChange={e=>setDuration(e.target.value)}><option>коротко</option><option>нормально</option><option>долго</option></select></Field><Field label="насколько вероятно, что позовёте друга? · 0–10"><input type="number" min="0" max="10" value={inviteFriend} onChange={e=>setInvite(Math.max(0,Math.min(10,Number(e.target.value))))}/></Field><Field label="сколько нормально платить за следующий офлайн?"><input type="number" step="100" value={willingness} onChange={e=>setWtp(Number(e.target.value))}/></Field><Button onClick={async()=>{await callApi('submit-feedback',{feedback:{returnIntent,strongest,improve,willingness,durationFeel,inviteFriend}});await reload()}}>отправить</Button></Card>}

function Finalists({title,items}:{title:string;items:{name:string;sub:string}[]}){return <Card><div className="section-title">{title}</div>{items.length?items.map((x,i)=><div className="finalist" key={i}><span>0{i+1}</span><div><b>{x.name}</b><p>{x.sub}</p></div></div>):<Empty>джипитина ещё думает</Empty>}</Card>}

function Club(){const {data,error}=useStateData();if(!data)return <Loading error={error}/>;return <div className="page"><h2>клуб</h2><Card><div className="section-title">таблица прогнозистов</div>{data.leaderboard.map((r,i)=><div className="leader" key={r.name}><span>{i+1}</span><b>{r.name}</b><strong>{r.points}</strong><small>{r.wins} побед · {r.events} веч.</small></div>)}</Card><Card><div className="section-title">следом</div><p>история показов, ваши оценки, артефакты, знакомства, секретный билет и разговоры с джипитиной о других фильмах</p></Card></div>}

function Admin(){const {data,error,reload}=useStateData();const [cap,setCap]=useState(30);const [message,setMessage]=useState('');if(!data)return <Loading error={error}/>;const idx=stages.indexOf(data.event.status);const setStage=async(status:EventStatus)=>{await callApi('admin-stage',{status});await reload()};return <div className="admin-page"><div className="row spread"><div><div className="eyebrow">режиссёрский пульт</div><h2>{data.event.title}</h2></div><Pill>{data.event.status}</Pill></div><div className="admin-grid"><Card><div className="section-title">этап вечера</div><div className="stage-list">{stages.map((s,i)=><button key={s} className={s===data.event.status?'current':i<idx?'done':''} onClick={()=>setStage(s)}><span>{String(i+1).padStart(2,'0')}</span>{statusLabel(s)}</button>)}</div></Card><div className="stack"><Card><div className="section-title">быстрые действия</div><Button onClick={()=>idx<stages.length-1&&setStage(stages[idx+1])}>следующий этап →</Button>{demoMode&&<Button kind="secondary" onClick={()=>idx>0&&setStage(stages[idx-1])}>← предыдущий (демо)</Button>}</Card><Card><div className="section-title">вместимость</div><div className="inline"><input type="number" value={cap} onChange={e=>setCap(Number(e.target.value))}/><Button onClick={async()=>{await callApi('admin-capacity',{capacity:cap});await reload()}}>применить</Button></div><p className="muted">сейчас {data.event.capacity}; продано {data.event.sold}</p></Card><Card><div className="section-title">сообщение на экран</div><textarea value={message} onChange={e=>setMessage(e.target.value)} placeholder="например: 10 минут до начала"/><Button onClick={async()=>{await callApi('admin-screen-message',{message});await reload()}}>показать</Button></Card><SmartAdmin data={data} reload={reload}/>{demoMode&&<Card className="dev"><Button kind="danger" onClick={async()=>{await callApi('reset-demo');location.reload()}}>сбросить демо</Button></Card>}</div></div></div>}

function SmartAdmin({data,reload}:{data:DemoState;reload:()=>void}){
  const [busy,setBusy]=useState(''); const [actuals,setActuals]=useState<Record<string,boolean>>({})
  const run=async(action:string,payload:Record<string,unknown>={})=>{try{setBusy(action);await callApi(action,{slug:data.event.slug,actuals,...payload});await reload()}finally{setBusy('')}}
  const s=data.event.status
  let action:string|undefined,label:string|undefined
  if(s==='IDEAS_LOCKED'){action='ai-select-ideas';label='джипитина: выбрать топ-3'}
  else if(s==='TOP3_READY'){action='draw-idea';label='запустить рандом идеи'}
  else if(['IDEA_RANDOMIZED','MOVIE_SEARCH'].includes(s)){action='ai-find-movies';label='найти и проверить фильмы'}
  else if(s==='MOVIE_FINALISTS'){action='draw-movie';label='запустить рандом фильма'}
  else if(s==='MOVIE_SELECTED'){action='ai-generate-predictions';label='сгенерировать 10 прогнозов'}

  if(['WATCHING','PREDICTIONS_LOCKED'].includes(s)&&data.predictions.length){return <Card><div className="section-title">факт-чек прогнозов</div>{data.predictions.map(p=><div className="prediction" key={p.id}><b>{p.position}. {p.text}</b><div className="binary"><button className={actuals[p.id]===true?'active':''} onClick={()=>setActuals({...actuals,[p.id]:true})}>было</button><button className={actuals[p.id]===false?'active':''} onClick={()=>setActuals({...actuals,[p.id]:false})}>не было</button></div></div>)}<Button disabled={Object.keys(actuals).length!==data.predictions.length||!!busy} onClick={()=>run('admin-score-predictions')}>посчитать победителя</Button></Card>}

  if(s==='PREDICTIONS_SCORED'){
    const score:any=data.outputs?.score_summary
    const tiebreaker:any=data.outputs?.tiebreaker
    if(!score)return <Card><div className="section-title">результаты</div><p className="muted">нет сохранённого подсчёта. верните этап в просмотр только через аварийный сценарий и пересчитайте прогнозы</p></Card>
    return <Card><div className="section-title">победитель прогнозов</div>
      {score.winner&&!score.tie?<div className="success">победитель: {score.winner.name}</div>:<>
        <p>ничья между: {(score.winners||[]).map((x:any)=>x.name).join(', ')}</p>
        <Button disabled={!!busy} onClick={()=>run('ai-tiebreaker')}>{tiebreaker?'сгенерировать ещё убогий пересказ':'джипитина: сделать тай-брейкер'}</Button>
        {tiebreaker?.clue&&<div className="output-json">{tiebreaker.clue}</div>}
        {tiebreaker?.clue&&<div className="stack"><p className="muted">кто первым угадал?</p>{(score.winners||[]).map((w:any)=><Button key={w.userId} kind="secondary" disabled={!!busy} onClick={()=>run('admin-set-winner',{userId:w.userId})}>{w.name}</Button>)}</div>}
      </>}
    </Card>
  }

  if(s==='CLOSED'){
    const research:any=data.outputs?.research_summary
    return <><Card><div className="section-title">после вечера</div><Button disabled={!!busy} onClick={()=>run('admin-research-summary')}>посчитать исследование</Button><Button kind="secondary" disabled={!!busy} onClick={()=>run('ai-finalize-memory')}>сохранить память джипитины</Button></Card>{research&&<Card><div className="section-title">результат теста</div><div className="big-copy">{research.returnIntentPositivePct}% хотят вернуться</div><p>NPS: {research.nps??'—'} · средняя готовность платить: {research.averageWillingnessRub??'—'} ₽ · ответов: {research.responses}</p><pre className="output-json">{JSON.stringify(research,null,2)}</pre></Card>}</>
  }
  if(s==='DISCUSSION'){action='ai-post-film-synthesis';label='джипитина: собрать разбор группы'}
  else if(s==='FINAL_REVIEW'){action='ai-collective-review';label='собрать черновик общей рецензии'}
  if(!action)return <Card><div className="section-title">автоматизация</div><p className="muted">на этом этапе отдельное действие джипитины не требуется</p></Card>
  return <><Card><div className="section-title">автоматизация</div><Button disabled={!!busy} onClick={()=>run(action!)}>{busy?'джипитина работает…':label}</Button></Card>{data.outputs&&Object.keys(data.outputs).length>0&&<Card><div className="section-title">последний AI-результат</div><pre className="output-json">{JSON.stringify(data.outputs,null,2)}</pre></Card>}</>
}

function Screen(){const {data,error}=useStateData();if(!data)return <Loading error={error}/>;const s=data.event.status;const content=screenContent(data);return <div className="screen-page"><div className="screen-brand">насыпатели в кино</div><div className="screen-status">{statusLabel(s)}</div>{data.screenMessage&&<div className="screen-message">{data.screenMessage}</div>}<div className="screen-content">{content}</div><div className="screen-footer">3 октября · никто заранее не знает фильм</div></div>}

function screenContent(d:DemoState){const s=d.event.status;if(['DRAFT','SALES_OPEN','CHECKIN'].includes(s))return <><h1>этого фильма<br/>не существует</h1><p>{d.event.sold}/{d.event.capacity} внутри</p></>;if(s==='IDEAS_OPEN')return <><h1>придумайте<br/>несуществующий фильм</h1><p>название + короткий сюжет</p></>;if(['IDEAS_LOCKED','TOP3_READY'].includes(s))return <><h1>джипитина выбрала три</h1>{d.ideaFinalists.map((x,i)=><h3 key={x.id}>{i+1}. {x.title}</h3>)}</>;if(['IDEA_RANDOMIZED','MOVIE_SEARCH'].includes(s))return <><div className="scan huge">поиск реального двойника</div><h1>{d.selectedIdea?.title}</h1>{d.selectedIdea?.author&&<p>автор: {d.selectedIdea.author}</p>}</>;if(s==='MOVIE_FINALISTS')return <><h1>финальная тройка</h1>{d.movieFinalists.map((x,i)=><h3 key={x.id}>{i+1}. {x.title} · {x.runtimeMin} мин</h3>)}</>;if(['MOVIE_SELECTED','PREDICTIONS_OPEN','PREDICTIONS_LOCKED'].includes(s))return <><div className="eyebrow">сегодня смотрим</div><h1>{d.selectedMovie?.title}</h1><p>{d.selectedMovie?.year} · {d.selectedMovie?.runtimeMin} минут</p></>;if(s==='WATCHING')return <><h1>смотрим</h1><p>телефоны вниз</p></>;if(s==='PREDICTIONS_SCORED'){const score:any=d.outputs?.score_summary;const t:any=d.outputs?.tiebreaker;if(score?.winner&&!score?.tie)return <><div className="eyebrow">победитель прогнозов</div><h1>{score.winner.name}</h1><p>артефакт джипитины уходит сюда</p></>;if(score?.tie&&t?.clue)return <><div className="eyebrow">тай-брейкер</div><h1>{t.clue}</h1><p>кто первым назовёт фильм?</p></>;return <><h1>кто угадал?</h1>{(score?.scores||d.leaderboard).slice(0,3).map((r:any,i:number)=><h3 key={r.userId||r.name}>{r.rank||i+1}. {r.name} — {r.points}</h3>)}</>}if(s==='DISCUSSION'){const o:any=d.outputs?.post_film_synthesis;return o?<><div className="eyebrow">джипитина</div><h1>{o.consensus}</h1><p>{o.jipitinaTake}</p></>:<><h1>что вы<br/>только что увидели?</h1><p>джипитина читает ваши мысли</p></>}if(s==='FINAL_REVIEW')return <><h1>одна фраза.<br/>без редактуры</h1></>;if(s==='FEEDBACK')return <><h1>это был тест</h1><p>помогите решить, делать ли второй</p></>;return <><h1>конец первого вечера</h1><p>рецензия — завтра</p></>}

function statusLabel(s:EventStatus){const m:Record<EventStatus,string>={DRAFT:'черновик',SALES_OPEN:'продажа билетов',CHECKIN:'сбор гостей',IDEAS_OPEN:'заявки открыты',IDEAS_LOCKED:'заявки закрыты',TOP3_READY:'три идеи выбраны',IDEA_RANDOMIZED:'идея выбрана',MOVIE_SEARCH:'поиск фильма',MOVIE_FINALISTS:'три фильма',MOVIE_SELECTED:'фильм выбран',PREDICTIONS_OPEN:'прогнозы открыты',PREDICTIONS_LOCKED:'прогнозы закрыты',WATCHING:'просмотр',PREDICTIONS_SCORED:'результаты',DISCUSSION:'обсуждение',FINAL_REVIEW:'финальная рецензия',FEEDBACK:'обратная связь',CLOSED:'закрыто'};return m[s]}

export default function App(){return <BrowserRouter><Routes><Route element={<Layout/>}><Route path="/" element={<Home/>}/><Route path="/profile" element={<Profile/>}/><Route path="/event/:slug" element={<EventPage/>}/><Route path="/club" element={<Club/>}/></Route><Route path="/admin/:slug" element={<Admin/>}/><Route path="/screen/:slug" element={<Screen/>}/></Routes></BrowserRouter>}

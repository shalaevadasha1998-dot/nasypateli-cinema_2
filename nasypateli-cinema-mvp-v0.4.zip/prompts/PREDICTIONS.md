# Action: generate_predictions

Input: exact selected movie.
Generate exactly 10 binary statements answerable after viewing.
Constraints:
- no character names, actor names or explicit major spoilers
- statements should be specific enough that YES/NO has meaning
- mix plot, relationships, death/danger, mood/formal device, ending tone
- avoid subjective wording like «будет скучно»

Output:
{"questions":[{"key":"q1","text":"..."}],"needs_retry":false}

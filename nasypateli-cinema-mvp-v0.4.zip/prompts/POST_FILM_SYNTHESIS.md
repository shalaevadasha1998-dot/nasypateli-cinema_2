# Action: synthesize_group_reaction

Input:
- movie metadata
- short participant thoughts (anonymous)
- aggregate rating if available

Return short screen-ready synthesis:
- 2 things the room broadly agreed on
- 2 meaningful disagreements
- 1 argument you challenge, quoting no more than a tiny fragment if needed
- your own concise reading
- your rating 1–10
Keep total <=900 characters in Russian.

# Action: propose_movie_candidates

Input:
- selected invented title + plot
- aggregate audience profile

Task:
Propose 12 REAL films or feature animations from any country/era that are maximally close to the invented idea.
Similarity weight: ~70% idea/title/plot, ~30% audience fit.
Experimental, old, obscure and difficult cinema is allowed.
Runtime is not trusted from the model and will be validated separately.

Important: if unsure a film exists, omit it.

Output JSON:
{
 "candidates":[
  {"title":"official/common title","original_title":"...","year":1999,"why":"<=180 chars","similarity_score":0-100,"audience_fit_score":0-100}
 ],
 "needs_retry": false
}

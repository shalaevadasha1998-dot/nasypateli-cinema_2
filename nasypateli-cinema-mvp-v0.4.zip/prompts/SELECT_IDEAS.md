# Action: select_top3_ideas

Input:
- anonymous submissions: [{submission_id,title,plot}]
- aggregate audience profile

Task:
Choose exactly 3 submissions that create the strongest blind-watch event. Optimize for:
1. vivid/distinct premise
2. searchability against real cinema without making it obvious
3. productive discussion potential
4. strangeness/character
Avoid choosing three near-duplicates.

Output JSON:
{
  "selected": [
    {"submission_id":"uuid","reason":"<=120 chars"}
  ],
  "needs_retry": false
}

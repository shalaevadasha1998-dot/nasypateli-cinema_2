# Action: build_collective_review_draft

Input:
- selected movie
- mean group rating
- ALL final participant sentences verbatim
- event metadata

Do not edit participant sentences. Produce a publication package with:
- headline options (3)
- factual intro <=250 chars
- mean rating
- ordered verbatim sentence array
- suggested final line from the club (not pretending to be participant text)
- layout notes for designer
Human approval required before publication.

# Action: rerank_validated_films

Input contains only externally validated films with runtime <=150 minutes.
Compute weighted score = 0.70*similarity + 0.30*audience_fit.
Return exactly 3 finalists, ordered by score. Do not add new films.

#!/usr/bin/env bash
set -euo pipefail
APP="$(cd "$(dirname "$0")" && pwd)/web/src/App.tsx"
CSS="$(cd "$(dirname "$0")" && pwd)/web/src/styles.css"
# Regression: never normalize a controlled text field back from parsed arrays on each keystroke.
! grep -q "value={form.favoriteGenres.join" "$APP"
! grep -q "value={form.favoriteFilms.join" "$APP"
! grep -q "value={form.avoid.join" "$APP"
grep -q "value={listDrafts.favoriteGenres}" "$APP"
grep -q "value={listDrafts.favoriteFilms}" "$APP"
grep -q "value={listDrafts.avoid}" "$APP"
grep -q "disabled={busy} onClick={next}" "$APP"
grep -q "min-height:44px" "$CSS"
echo "UX regression checks: OK"

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

required=(
  README.md
  web/package.json
  web/src/App.tsx
  supabase/config.toml
  supabase/schema.sql
  supabase/PATCH_V0_4.sql
  supabase/functions/app/index.ts
  supabase/functions/app/ui.ts
  supabase/functions/app/_shared/state.ts
  supabase/functions/app/handlers/api.ts
  supabase/functions/app/handlers/telegram.ts
  supabase/functions/app/handlers/invoice.ts
)
for f in "${required[@]}"; do
  test -f "$f" || { echo "missing: $f" >&2; exit 1; }
done

if grep -RIEq --exclude-dir=node_modules --exclude='*.example' --exclude='scripts-sanity-check.sh' '(sk-[A-Za-z0-9_-]{20,}|TELEGRAM_BOT_TOKEN=[^[:space:]]+|OPENAI_API_KEY=[^[:space:]]+|SUPABASE_SERVICE_ROLE_KEY=[^[:space:]]+)' .; then
  echo 'possible secret found; review before commit' >&2
  exit 1
fi

if grep -RIEq 'TODO.*initData HMAC|TODO.*successful_payment' supabase/functions; then
  echo 'stale security skeleton detected' >&2
  exit 1
fi

echo 'sanity check: ok'

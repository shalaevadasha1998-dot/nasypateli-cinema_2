#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/demo"
echo "Open http://localhost:8080"
python3 -m http.server 8080

#!/usr/bin/env bash
set -euo pipefail
PROJECT_REF=vwteokawtqnoiyzmsldj
supabase link --project-ref "$PROJECT_REF"
echo "Linked to $PROJECT_REF"

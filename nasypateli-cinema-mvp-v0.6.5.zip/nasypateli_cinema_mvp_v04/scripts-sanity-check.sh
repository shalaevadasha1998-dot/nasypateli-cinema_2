#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

required=(
  README.md
  web/package.json
  web/src/App.tsx
  supabase/config.toml
  supabase/schema.sql
  supabase/PATCH_V0_4.sql
  supabase/functions/app/index.ts
  supabase/functions/app/ui.ts
  supabase/functions/app/_shared/state.ts
  supabase/functions/app/handlers/api.ts
  supabase/functions/app/handlers/telegram.ts
  supabase/functions/app/handlers/invoice.ts
)
for f in "${required[@]}"; do
  test -f "$f" || { echo "missing: $f" >&2; exit 1; }
done

if grep -RIEq --exclude-dir=node_modules --exclude='*.example' --exclude='scripts-sanity-check.sh' '(sk-[A-Za-z0-9_-]{20,}|TELEGRAM_BOT_TOKEN=[^[:space:]]+|OPENAI_API_KEY=[^[:space:]]+|SUPABASE_SERVICE_ROLE_KEY=[^[:space:]]+)' .; then
  echo 'possible secret found; review before commit' >&2
  exit 1
fi

if grep -RIEq 'TODO.*initData HMAC|TODO.*successful_payment' supabase/functions; then
  echo 'stale security skeleton detected' >&2
  exit 1
fi

echo 'sanity check: ok'

# v0.6.5 regression guards: these are easy to accidentally remove while editing the one-file handlers/UI.
grep -q "version:'0.6.5'" supabase/functions/app/handlers/api.ts || { echo 'backend version guard failed' >&2; exit 1; }
grep -q "lastLovedFilm" supabase/functions/app/handlers/api.ts || { echo 'profile validation guard failed' >&2; exit 1; }
grep -q "notificationsQuietNow" supabase/functions/app/handlers/api.ts || { echo 'quiet-hours guard failed' >&2; exit 1; }
grep -q "allowedGender(mine.data.show_gender" supabase/functions/app/handlers/api.ts || { echo 'dating filter guard failed' >&2; exit 1; }
grep -q "encounter_tokens'" supabase/functions/app/handlers/api.ts || { echo 'profile deletion guard failed' >&2; exit 1; }
grep -q "payerOk" supabase/functions/app/handlers/telegram.ts || { echo 'payment payer guard failed' >&2; exit 1; }
grep -q "не считаем" web/src/App.tsx || { echo 'void prediction UI guard failed' >&2; exit 1; }
grep -q "admin-configure-telegram" web/src/App.tsx || { echo 'admin telegram setup guard failed' >&2; exit 1; }
grep -q '"version": "0.6.5"' web/package.json || { echo 'frontend version guard failed' >&2; exit 1; }
grep -q "includePrivateOutputs" supabase/functions/app/_shared/state.ts || { echo 'output privacy guard failed' >&2; exit 1; }
grep -q "admin-approve-output" supabase/functions/app/handlers/api.ts || { echo 'output approval guard failed' >&2; exit 1; }
grep -q "telegramStartLink" supabase/functions/app/handlers/api.ts || { echo 'encounter deep-link guard failed' >&2; exit 1; }
grep -q "hidden_by" supabase/functions/app/_shared/dating.ts || { echo 'per-user match hide guard failed' >&2; exit 1; }
grep -q "count:'exact'" supabase/functions/app/_shared/stories.ts || { echo 'story count guard failed' >&2; exit 1; }
grep -q "получить ссылку чек-ина" web/src/App.tsx || { echo 'admin check-in link UI guard failed' >&2; exit 1; }
grep -q "получить ссылку моей Животины" web/src/ProductPages.tsx || { echo 'creature encounter link UI guard failed' >&2; exit 1; }
grep -q "admin-confirm-movie-availability" supabase/functions/app/handlers/api.ts || { echo 'movie availability guard failed' >&2; exit 1; }
grep -q "admin-event-config" supabase/functions/app/handlers/api.ts || { echo 'event config guard failed' >&2; exit 1; }
grep -q "admin-export-event" supabase/functions/app/handlers/api.ts || { echo 'event export guard failed' >&2; exit 1; }
grep -q "скачать CSV" web/src/App.tsx || { echo 'event export UI guard failed' >&2; exit 1; }

echo 'v0.6.5 regression guards: ok'

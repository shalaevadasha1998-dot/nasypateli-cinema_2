# NASYPATELI CINEMA v0.8.0

# НАСЫПАТЕЛИ В КИНО — MVP v0.6.4

Рабочий MVP киноклуба для первого офлайна 3 октября 2026.

## Что реализовано

- React/Vite Telegram Mini App (`web/`) — это актуальный production participant UI
- отдельные защищённые admin и projector routes в том же frontend
- Supabase Edge Function `app` как единый API + Telegram webhook + invoice endpoint
- demo mode без внешних ключей
- Telegram initData server-side validation
- onboarding/кинопрофиль, birth flow Животины, истории/крошки/косметика
- Джипитина: GPT-чат, voice input, persistent memory
- dating 18+ opt-in: взаимные фильтры, свайпы, мэтчи, hide/block
- QR/NFC-compatible encounter tokens и event check-in
- уведомления через очередь + cron dispatcher + quiet hours
- event flow «несуществующий фильм»: идеи → GPT top-3 → random → поиск реальных фильмов → random → 10 прогнозов → факт-чек → обсуждение → коллективная рецензия → feedback
- Telegram invoice flow с резервацией места, waitlist, payer/amount/currency validation
- admin controls: стадии, платная механика, capacity, экран, Telegram webhook/menu setup, тестовые билеты
- удаление персонального профиля при сохранении минимальных билетных/платёжных записей

## Важное про архитектуру

`web/` — актуальная v0.6.4 Mini App. Её и нужно ставить в `TELEGRAM_WEBAPP_URL`.

`supabase/functions/app/ui.ts` — legacy no-build fallback от раннего MVP. Он оставлен как аварийная страница/исторический admin fallback, но **не содержит полного v0.6 UX** (Животина, dating, новый onboarding и т. д.) и не должен быть production Mini App URL.

## База

Для существующего проекта патчи применяются по порядку:

1. `supabase/PATCH_V0_4.sql`
2. `supabase/PATCH_V0_5.sql`
3. `supabase/PATCH_V0_6.sql`

Для нового проекта сначала используется `supabase/SETUP_THIS_PROJECT.sql` / базовая schema, затем актуальные патчи.

## Быстрый локальный smoke test

Без внешних сервисов:

```bash
./scripts-run-demo.sh
```

Статические проверки:

```bash
./scripts-sanity-check.sh
./scripts-ux-regression-check.sh
```

Production-порядок: `docs/DEPLOY_NOW.md`.

## Структура

- `web/` — production React/Vite Mini App + admin + projector screen
- `supabase/functions/app/` — backend API, Telegram webhook, invoice endpoint; GET оставлен legacy fallback
- `supabase/` — schema, seed, SQL patches
- `demo/` — no-dependency smoke test
- `prompts/` — prompt specs
- `docs/` — продуктовая архитектура, QA и запуск

## Что всё ещё требует внешнего доступа владельца

Секреты/аккаунты и реальные deployment actions: Supabase secrets, frontend hosting, Telegram Bot settings, OpenAI API key, scheduler для уведомлений и позже платёжный провайдер. До реальных продаж также нужен тест платежа/возврата и решённый вопрос прав на публичный показ фильма.

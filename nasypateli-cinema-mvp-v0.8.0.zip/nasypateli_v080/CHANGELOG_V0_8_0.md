# v0.8.0 — motion + continuity pass

Based on the 13.37s real Telegram Mini App screen recording captured 2026-09-22.

## What the recording proved
- Birth was visually understandable, but the rabbit read as a static cut-out rather than a living drawn character.
- Phase changes were too fast and copy swapped abruptly.
- Popcorn kernels read as grey circles more than popcorn.
- The cup and rabbit stayed too close together on the naming composition.
- The user reached the name field, but save hit an old-server `Admin access required` path and the journey stopped.
- The error exposed infrastructure wording to the participant.

## Changes
- Birth save now uses the backwards-compatible `birth-creature` action first and only falls back to `participant-birth-v2`; it works against the older deployed backend as well as 0.8.0.
- Pending creature name is persisted locally, so a failed request never forces retyping.
- Internal server/version errors are no longer shown to participants.
- Created three transparent canonical cel poses from the approved rabbit art: back / side / front.
- Rebuilt the jump as a 3-pose cel sequence with squash, arc, landing, shadow and a second name-reaction hop.
- Rabbit is materially smaller in the birth sequence so growth still has meaning.
- Removed the visible black rectangles around rabbit source art.
- Rebuilt popcorn kernels as irregular three-lobe shapes instead of circles.
- Slowed birth beats to let the interaction read as a scene rather than a state machine.
- Birth copy remounts per phase, giving every beat a short dissolve/slide instead of an instant text swap.
- Naming composition separates cup and rabbit and reduces their visual weight around the form.
- Progress marker now reads `07/07` instead of the ambiguous `07½`.

## Compatibility
- Frontend 0.8.0 can complete creature birth even if Supabase is still serving the 0.6.x/0.7.x birth handler.
- Backend 0.8.0 keeps both `birth-creature` and `participant-birth-v2` aliases.

# Запуск MVP v0.6.4

Актуальная инструкция: `DEPLOY_NOW.md`.

## Production architecture

- `web/` — Telegram Mini App, admin и projector screen
- Supabase Edge Function `app` — API, Telegram webhook и invoice endpoint

Не ставить URL GET Edge Function как production Mini App: встроенный `ui.ts` — legacy fallback и не содержит полного v0.6 продукта.

## Доступ

- participant: Telegram `initData` HMAC
- admin: `ADMIN_ACCESS_TOKEN`
- screen: `SCREEN_ACCESS_TOKEN`
- notification cron: `CRON_ACCESS_TOKEN`
- Telegram webhook: `TELEGRAM_WEBHOOK_SECRET`

## Payments

До подключения провайдера `TELEGRAM_PROVIDER_TOKEN` не задаётся. Для smoke test React admin умеет выдавать бесплатный тестовый билет по Telegram username пользователю, который уже один раз открыл Mini App.

Production payment включать только после теста платежа и возврата и после решения вопроса прав на публичный показ.

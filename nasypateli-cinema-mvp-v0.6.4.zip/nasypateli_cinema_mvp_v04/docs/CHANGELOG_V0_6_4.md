# v0.6.4 — continuation handoff

Дата: 22 сентября 2026.

Эта версия продолжает архив, который назывался `v0.4`, но фактически содержал продуктовый слой v0.6.3.

## Что изменено

- исправлены backend validation и реальные счётчики attendance/story count
- усилена Telegram payment validation и idempotency
- quiet hours стали реальной логикой dispatcher
- dating filters/blocks проверяются на сервере
- персональное скрытие мэтча больше не ломает связь второго участника
- GPT matchmaker работает только с реальными eligible cards и не получает internal ids
- исправлена приватность event outputs; admin-only и unapproved outputs не уходят участникам
- добавлен approve flow для collective review/post-film synthesis
- encounter/check-in backend доведён до готовых Telegram deep links и UI
- React admin получил Telegram setup, test ticket и check-in link
- React admin получил event config (дата/время, цена, runtime cap, venue), CSV/JSON export и ручной movie availability gate
- таймауты frontend разделены по типу операции
- исправлена deploy architecture: production Mini App = `web/`, Edge Function = API/webhook/payment; `ui.ts` только legacy fallback

## Проверки

`./scripts-release-check.sh` должен проходить перед deploy. Он запускает sanity, UX regression и syntax-only TypeScript checks.

Полный production `npm run build` нужно выполнить в среде с установленными npm dependencies. Реальные Telegram/OpenAI/payment/device сценарии требуют staging/production smoke test.

## Следующая точка

Не переписывать frontend обратно на `ui.ts`. Дальше — deploy по `docs/DEPLOY_NOW.md`, затем real-device smoke по `docs/QA_V0_6_4.md`.

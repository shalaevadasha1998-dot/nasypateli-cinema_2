# Deploy v0.6.4 — правильный production путь

Для v0.6.4 используются **два deployment target**:

1. `web/` → HTTPS static hosting (например, Cloudflare Pages) — Mini App + admin + projector screen
2. `supabase/functions/app` → Supabase Edge Function — API + Telegram webhook + invoice endpoint

Старый GET UI внутри Edge Function — legacy fallback и не должен быть Telegram Mini App URL.

## 1. База

Для уже созданной базы выполнить отсутствующие патчи по порядку:

1. `supabase/PATCH_V0_4.sql`
2. `supabase/PATCH_V0_5.sql`
3. `supabase/PATCH_V0_6.sql`

Не запускать произвольные старые schema-файлы поверх живой базы вместо миграций.

## 2. Supabase Edge Function secrets

Обязательные до production smoke test:

- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_WEBAPP_URL` — пока можно оставить пустым до шага 4, потом записать HTTPS URL frontend
- `TELEGRAM_WEBHOOK_SECRET`
- `OPENAI_API_KEY`
- `OPENAI_MODEL=gpt-5.6-luna`
- `OPENAI_FILM_MODEL=gpt-5.6-terra`
- `ALLOW_DEMO_AUTH=false`
- `ADMIN_ACCESS_TOKEN`
- `SCREEN_ACCESS_TOKEN`
- `CRON_ACCESS_TOKEN`
- `NOTIFICATION_TIMEZONE=Europe/Moscow` для первого московского события

`TELEGRAM_PROVIDER_TOKEN` не задавать до подключения провайдера и отдельного payment smoke test.

## 3. Deploy backend

Deploy `supabase/functions/app` как функцию `app`.

Для `app` built-in Supabase JWT verification должен быть выключен: participant requests проверяются через Telegram initData HMAC, admin/screen/cron — собственными токенами, webhook — Telegram secret token.

Backend URL:

`https://vwteokawtqnoiyzmsldj.supabase.co/functions/v1/app`

Webhook endpoint:

`https://vwteokawtqnoiyzmsldj.supabase.co/functions/v1/app?mode=telegram`

Invoice endpoint:

`https://vwteokawtqnoiyzmsldj.supabase.co/functions/v1/app?mode=invoice`

## 4. Deploy frontend `web/`

Production env:

```text
VITE_DEMO_MODE=false
VITE_SUPABASE_URL=https://vwteokawtqnoiyzmsldj.supabase.co
VITE_API_FUNCTION=app
```

Build command from directory `web/`:

```bash
npm install
npm run build
```

Output directory: `dist`.

`web/public/_redirects` уже содержит SPA fallback для static hosting.

После публикации взять HTTPS URL, например `https://<site>.pages.dev`, и записать **его** в Supabase secret `TELEGRAM_WEBAPP_URL`.

## 5. URLs React app

Участник:

`https://<frontend>/#/`

Admin:

`https://<frontend>/#/admin/2026-10-03?token=<ADMIN_ACCESS_TOKEN>`

Projector screen:

`https://<frontend>/#/screen/2026-10-03?token=<SCREEN_ACCESS_TOKEN>`

Токены admin/screen не коммитить и не отправлять публично.

## 6. Подключить Telegram

После того как `TELEGRAM_WEBAPP_URL` задан:

1. открыть React admin URL
2. блок `технический запуск`
3. нажать `подключить webhook + кнопку бота`

Backend вызовет Telegram `setWebhook`, `setChatMenuButton` и `setMyCommands`.

## 7. Настроить уведомления

Scheduler должен вызывать POST action `cron-notifications` минимум раз в час (лучше чаще, если платформа позволяет), передавая header:

`x-cron-token: <CRON_ACCESS_TOKEN>`

Quiet hours: 22:00–09:00 по `NOTIFICATION_TIMEZONE`; сообщения остаются pending и уйдут после окончания quiet hours.

## 8. Smoke test без оплаты

1. реальный пользователь открывает бота → `/start` → Mini App
2. проходит onboarding и birth flow
3. admin выдаёт тестовый билет по `@username`
4. проверить participant/admin/screen одновременно
5. пройти check-in → идеи → random → movie selection → predictions → viewing → fact-check → discussion → review → feedback
6. проверить Животину, GPT chat, voice, dating opt-in и уведомления

## 9. Перед продажами

- подключить payment provider и только тогда добавить `TELEGRAM_PROVIDER_TOKEN`
- провести реальный test payment + refund
- проверить support flow `/paysupport`
- решить право на публичный показ выбранного фильма

До этого тестовые билеты из admin — правильный путь.

# Backlog — 22 September 2026

## NOW — внешний запуск до 3 October

- площадка: финально подтвердить venue до 5h, свой напиток, projector/sound/Wi-Fi
- public screening rights workflow
- self-employed / payment provider onboarding, если билеты продаются через Telegram invoice
- применить недостающие SQL patches v0.4 → v0.5 → v0.6
- deploy Edge Function `app`
- deploy `web/` frontend и поставить URL в `TELEGRAM_WEBAPP_URL`
- настроить webhook/menu button и notification scheduler
- real Telegram smoke test минимум на 2–3 устройствах
- dry run полного event flow на 5–8 людях
- Telegram channel + Instagram/TikTok launch
- free distribution по релевантным открытым московским группам/чатам
- content shoot list + физический collectible artifact

## APP — после production smoke

- добавить automated integration tests против отдельного Supabase staging project
- добавить error/latency monitoring для Edge Function и frontend
- добавить delivery retry policy для временных Telegram Bot API ошибок
- проверить и при необходимости локализовать quiet-hours timezone для участников вне Москвы

## NEXT — after first event

- проверить retention/KPI на фактических данных первого события
- online blind watch только после решения legal streaming model
- улучшить archive/profile history по реальному поведению участников
- развивать leaderboard/achievements только по данным первого цикла, без click-grind
- weekly/seasonal secret mechanics
- viewer × Jipitina review flow на основе реальных разговоров

## LATER

- paid membership/subscription
- standalone personal AI cinema companion
- corporate/brand versions
- licensing / repeatable event format

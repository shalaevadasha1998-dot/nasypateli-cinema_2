# Notifications v0.6.4

Mini App запрашивает Telegram write access только по действию пользователя. В профиле отдельные настройки: события, сообщения Животины, новые истории, мэтчи, билеты, напоминания, quiet hours.

Notification queue отделена от отправки. Story engine и dating могут поставить сообщение в очередь. `cron-notifications` забирает due-записи, повторно проверяет write access и конкретную категорию уведомлений, затем отправляет через Telegram Bot API.

Quiet hours теперь реально исполняются backend: если `quiet_hours=true`, dispatcher не отправляет сообщения с 22:00 до 09:00 по `NOTIFICATION_TIMEZONE` (default `Europe/Moscow`). Запись остаётся `pending` и будет подобрана следующим cron run после окончания quiet hours.

Retention-принцип: никаких «Животина голодна, вернитесь». Поводы должны быть содержательными: реальное событие, новая история, мэтч, билет, персональная кино-рекомендация или редкая инициатива Животины.

Для production нужны `CRON_ACCESS_TOKEN`, `NOTIFICATION_TIMEZONE` и scheduler. Endpoint уже подготовлен; cron token нельзя хранить во frontend.

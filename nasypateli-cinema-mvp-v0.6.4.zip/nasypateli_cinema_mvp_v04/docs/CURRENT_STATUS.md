# Текущее состояние проекта

Обновлено: 22 сентября 2026. Кодовая версия: **v0.6.4**.

## Уже готово в репозитории

- Supabase project: `vwteokawtqnoiyzmsldj`
- Telegram bot: `@nasipateli_v_kinobot`
- GitHub repo: `shalaevadasha1998-dot/nasypateli-cinema_2`
- актуальный participant/admin/screen frontend: `web/`
- backend: `supabase/functions/app`
- SQL patches v0.4 → v0.5 → v0.6
- demo mode без внешних сервисов
- onboarding + кинопрофиль
- Животина: birth flow, крошки, истории, гардероб
- Джипитина: GPT/voice/memory
- dating + encounter/check-in
- notification queue + cron endpoint + quiet hours
- полный event flow, admin и screen

## Исправлено в v0.6.4

- Telegram имя больше не перетирает выбранное пользователем имя профиля при каждом запросе
- backend теперь требует `lastLovedFilm`, как и frontend
- leaderboard считает реальные `attended` registrations, а не наличие score row
- check-in считает гостей только текущего события
- prediction submit принимает только ровно 10 уникальных вопросов текущего события
- admin fact check поддерживает `не считаем` / void
- pre-checkout и successful payment проверяют Telegram payer, сумму, валюту и статус резерва; successful payment идемпотентен
- dating swipe повторно проверяет opt-in, pause, взаимные gender filters и blocks на сервере
- quiet hours реально соблюдаются cron dispatcher'ом
- delete profile чистит notification queue и личные encounter tokens
- GPT/voice/admin AI запросы получили реалистичные timeout вместо общего 8-second abort
- React admin получил Telegram setup и выдачу тестового билета
- participant bootstrap больше не раскрывает admin research и неутверждённые AI outputs; для post-film synthesis / collective review добавлен явный approve
- GPT-сваха получает только реальные доступные dating cards и только по явной просьбе пользователя
- story count больше не обрезается длиной timeline
- Животина и event check-in получили готовые Telegram deep links в UI, active token переиспользуется до expiry
- `скрыть мэтч` теперь скрывает связь только для нажавшего участника
- successful payment теперь проверяет результат записи билета в БД
- выбранный фильм нельзя протащить в прогнозы без ручного подтверждения технической доступности; есть redraw по оставшимся финалистам
- в admin добавлены настройки даты/времени, цены, runtime cap и venue с серверными guard'ами
- в admin добавлена выгрузка CSV/JSON по операционным и исследовательским данным вечера
- demo admin flow дополнен отсутствовавшими AI/draw/availability/export actions

## Критическое архитектурное уточнение

В старых инструкциях встречалось утверждение, что Edge Function GET сама является production Mini App. Для v0.6 это уже неверно: встроенный `ui.ts` — legacy интерфейс и не содержит полного нового продукта.

Production Telegram Mini App URL должен указывать на собранный `web/` frontend. Edge Function остаётся API/webhook/invoice backend.

## Что осталось сделать во внешних сервисах

1. проверить, какие из `PATCH_V0_4.sql`, `PATCH_V0_5.sql`, `PATCH_V0_6.sql` уже применены, и применить отсутствующие по порядку
2. задать Supabase Edge Function secrets
3. deploy Edge Function `app`
4. deploy `web/` на Cloudflare Pages или другой HTTPS static hosting
5. записать URL frontend в `TELEGRAM_WEBAPP_URL`
6. установить webhook/menu button через React admin или BotFather/API
7. настроить scheduler для `cron-notifications`
8. пройти real-device smoke test внутри Telegram

## Production-only проверки, которые нельзя честно закрыть статическим QA

- реальный Telegram initData/HMAC
- Menu Button/WebApp launch на iOS/Android/Desktop
- accelerometer/haptic и microphone permission на реальном устройстве
- OpenAI latency/limits с production key
- scheduler + Telegram write access
- реальный invoice/payment/refund после подключения provider token
- public screening rights

Подробно: `docs/QA_V0_6_4.md` и `docs/DEPLOY_NOW.md`.

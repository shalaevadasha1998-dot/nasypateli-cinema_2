#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

./scripts-sanity-check.sh
./scripts-ux-regression-check.sh

if command -v tsc >/dev/null 2>&1; then
  tsc --noEmit --noCheck --jsx react-jsx --module esnext --target es2022 --moduleResolution bundler --allowImportingTsExtensions \
    web/src/App.tsx web/src/ProductPages.tsx web/src/components/Layout.tsx web/src/lib/api.ts
  tsc --noEmit --noCheck --module esnext --target es2022 --moduleResolution bundler --allowImportingTsExtensions \
    supabase/functions/app/handlers/api.ts supabase/functions/app/handlers/telegram.ts supabase/functions/app/handlers/invoice.ts supabase/functions/app/_shared/dating.ts
else
  echo 'tsc not installed; syntax-only TypeScript pass skipped' >&2
fi

echo 'release check: ok'

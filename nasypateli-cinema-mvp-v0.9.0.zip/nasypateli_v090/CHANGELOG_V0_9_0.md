# v0.9.0 — cartoon / continuity pass

Based on the 2026-09-22 live Telegram recording.

## Birth scene
- Replaced CSS-transformed rabbit PNGs with actual frame-by-frame animated WebP sequences.
- Rabbit now has anticipation, reveal, take-off, pose changes in flight, landing squash/stretch and a stepped idle loop.
- Popcorn/cup are drawn into the same animation frames, so the scene reads as one cartoon instead of several UI layers.
- Reduced birth flow to four beats: sealed → cartoon hatch → name → named.
- Tiny rabbit stays tiny and receives a separate name-reaction animation.
- Added subtle print scratch / grain rather than glossy digital motion.

## Reliability
- Creature birth is optimistic on the client: name is kept locally and the user is allowed into the app immediately.
- Failed server sync is retried silently on subsequent bootstraps; users never see backend/version errors during the birth payoff.
- Bootstrap overlays pending local birth state until the server confirms it.
- Backend birth route now retries with a minimal field set for compatibility with older v0.6-era `creatures` tables.

## Home / polish
- Tiny creature on Home uses the living idle animation rather than a floating static PNG.
- Added subtle print grain and page-entry motion to participant screens.
